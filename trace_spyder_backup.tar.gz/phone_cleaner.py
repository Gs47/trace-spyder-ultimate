import os, sys, subprocess, shutil

C_CYAN = "\033[1;36m"
C_GREEN = "\033[1;32m"
C_YELLOW = "\033[1;33m"
C_RED = "\033[1;31m"
C_MAGENTA = "\033[1;35m"
C_WHITE = "\033[1;37m"
C_RESET = "\033[0m"

BANNER = """[1;36m┌────────────────────────────────────────────────────────────┐
[1;37m  ████████╗██████╗  █████╗  ██████╗███████╗
  ╚══██╔══╝██╔══██╗██╔══██╗██╔════╝██╔════╝
     ██║   ██████╔╝███████║██║     █████╗  
     ██║   ██╔══██╗██╔══██║██║     ██╔══╝  
     ██║   ██║  ██║██║  ██║╚██████╗███████╗
     ╚═╝   ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚══════╝

  ███████╗██████╗ ██╗   ██╗██████╗ ███████╗██████╗ 
  ██╔════╝██╔══██╗╚██╗ ██╔╝██╔══██╗██╔════╝██╔══██╗
  ███████╗██████╔╝ ╚████╔╝ ██║  ██║█████╗  ██████╔╝
  ╚════██║██╔═══╝   ╚██╔╝  ██║  ██║██╔══╝  ██╔══██╗
  ███████║██║        ██║   ██████╔╝███████╗██║  ██║
  ╚══════╝╚═╝        ╚═╝   ╚═════╝ ╚══════╝╚═╝  ╚═╝
[0m
             [1;33m🕷️  [1;36mT R A C E   S P Y D E R[1;33m  🕷️[0m
           [1;35m⚡ ═ [1;32mT E R M I N A L   H U B[1;35m ═ ⚡[0m
[1;36m└────────────────────────────────────────────────────────────┘[0m"""

def clear_screen():
    os.system('clear')
    print(BANNER)
    print(f"{C_MAGENTA}  [▸] ACTIVE MODULE : {C_GREEN}STORAGE & JUNK PURGER{C_RESET}")
    print(f"{C_CYAN}─"*60 + f"{C_RESET}")

def get_free_space():
    try:
        _, _, free_b = shutil.disk_usage('/sdcard')
        return free_b
    except Exception: return 0

def format_size(bytes_val):
    mb = bytes_val / (1024 * 1024)
    if mb >= 1024: return f"{mb / 1024:.2f} GB"
    return f"{mb:.2f} MB"

def clean_termux_junk():
    print(f"\n{C_YELLOW}[*] Purging temporary cache files...{C_RESET}")
    initial_free = get_free_space()
    paths = [
        "/data/data/com.termux/files/usr/tmp",
        os.path.expanduser("~/.cache"),
        os.path.expanduser("~/.npm"),
        os.path.expanduser("~/.pip")
    ]
    for p in paths:
        if os.path.exists(p):
            try:
                if os.path.isdir(p): shutil.rmtree(p, ignore_errors=True)
                else: os.remove(p)
                print(f"  {C_GREEN}[✓] Cleared:{C_RESET} {p}")
            except Exception: pass
            
    os.makedirs("/data/data/com.termux/files/usr/tmp", exist_ok=True)
    subprocess.run(["apt-get", "clean"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    subprocess.run(["pip", "cache", "purge"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    
    final_free = get_free_space()
    print(f"{C_CYAN}─"*60 + f"{C_RESET}")
    print(f"[*] Initial Free Space : {format_size(initial_free)}")
    print(f"[*] Current Free Space : {format_size(final_free)}")
    print(f"{C_GREEN}🔥 TOTAL SPACE RECLAIMED : {format_size(max(0, final_free - initial_free))}{C_RESET}")
    print(f"{C_CYAN}─"*60 + f"{C_RESET}")

def main():
    while True:
        clear_screen()
        print(f"  {C_CYAN}[1]{C_RESET} Run Termux Junk & Temp Cleaner")
        print(f"{C_CYAN}─"*60 + f"{C_RESET}")
        print(f"  {C_CYAN}[#]{C_RESET} Back to Main Menu")
        print(f"  {C_RED}[*]{C_RESET} Full Exit to Terminal")
        print(f"{C_CYAN}═"*60 + f"{C_RESET}")
        c = input(f"{C_GREEN}➤ Option: {C_RESET}").strip().lower()
        if c == '1':
            clean_termux_junk()
            input("\nPress Enter to continue...")
        elif c in ['#', 'b', 'back']: break
        elif c in ['*', 'x', 'exit', 'q']: os._exit(0)

if __name__ == "__main__": main()
