import os, sys, subprocess, shutil

C_CYAN = "\033[1;36m"
C_GREEN = "\033[1;32m"
C_YELLOW = "\033[1;33m"
C_RED = "\033[1;31m"
C_MAGENTA = "\033[1;35m"
C_WHITE = "\033[1;37m"
C_RESET = "\033[0m"

BANNER = """[1;36m┌────────────────────────────────────────────────────────────┐
[1;37m  ████████╗██████╗  █████╗  ██████╗███████╗
  ╚══██╔══╝██╔══██╗██╔══██╗██╔════╝██╔════╝
     ██║   ██████╔╝███████║██║     █████╗  
     ██║   ██╔══██╗██╔══██║██║     ██╔══╝  
     ██║   ██║  ██║██║  ██║╚██████╗███████╗
     ╚═╝   ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚══════╝

  ███████╗██████╗ ██╗   ██╗██████╗ ███████╗██████╗ 
  ██╔════╝██╔══██╗╚██╗ ██╔╝██╔══██╗██╔════╝██╔══██╗
  ███████╗██████╔╝ ╚████╔╝ ██║  ██║█████╗  ██████╔╝
  ╚════██║██╔═══╝   ╚██╔╝  ██║  ██║██╔══╝  ██╔══██╗
  ███████║██║        ██║   ██████╔╝███████╗██║  ██║
  ╚══════╝╚═╝        ╚═╝   ╚═════╝ ╚══════╝╚═╝  ╚═╝
[0m
             [1;33m🕷️  [1;36mT R A C E   S P Y D E R[1;33m  🕷️[0m
           [1;35m⚡ ═ [1;32mT E R M I N A L   H U B[1;35m ═ ⚡[0m
[1;36m└────────────────────────────────────────────────────────────┘[0m"""

def clear_screen():
    os.system('clear')
    print(BANNER)
    print(f"{C_MAGENTA}  [▸] ACTIVE MODULE : {C_GREEN}MAIN DASHBOARD{C_RESET}")
    print(f"{C_CYAN}─"*60 + f"{C_RESET}")

def run_script(script_name):
    path = os.path.expanduser(f"~/{script_name}")
    if os.path.exists(path):
        subprocess.run([sys.executable, path])
    else:
        print(f"\n{C_RED}❌ Error: {script_name} not found!{C_RESET}")
        input("Press Enter...")

def main_menu():
    while True:
        clear_screen()
        print(f"  {C_CYAN}[01]{C_RESET} Telegram Tools & Manager")
        print(f"  {C_CYAN}[02]{C_RESET} Ultimate Media Downloader (YT/IG/FB/X/etc)")
        print(f"  {C_CYAN}[03]{C_RESET} Spotify Music Downloader (320kbps)")
        print(f"  {C_CYAN}[04]{C_RESET} TeraBox Video Fast Downloader")
        print(f"  {C_CYAN}[05]{C_RESET} Media & Document Converter Engine")
        print(f"  {C_CYAN}[06]{C_RESET} Seeker OSINT Location Explorer")
        print(f"  {C_CYAN}[07]{C_RESET} Device & Battery Diagnostic Status")
        print(f"  {C_CYAN}[08]{C_RESET} Termux Storage & Cache Purger")
        print(f"  {C_CYAN}[09]{C_RESET} Settings & Engine Updater")
        print(f"  {C_CYAN}[10]{C_RESET} Full System Self-Repair & Auto-Fix Engine")
        print(f"{C_CYAN}─"*60 + f"{C_RESET}")
        print(f"  {C_YELLOW}[ 0]{C_RESET} Refresh Dashboard")
        print(f"  {C_RED}[ *]{C_RESET} Full Exit to Terminal")
        print(f"{C_CYAN}═"*60 + f"{C_RESET}")
        
        choice = input(f"{C_GREEN}➤ Select Option: {C_RESET}").strip().lower()
        mapping = {
            '1': 'tools.py', '01': 'tools.py',
            '2': 'media_dl.py', '02': 'media_dl.py',
            '3': 'spotify_dl.py', '03': 'spotify_dl.py',
            '4': 'terabox_dl.py', '04': 'terabox_dl.py',
            '5': 'converter.py', '05': 'converter.py',
            '6': 'seeker_hub.py', '06': 'seeker_hub.py',
            '7': 'device_info.py', '07': 'device_info.py',
            '8': 'phone_cleaner.py', '08': 'phone_cleaner.py',
            '9': 'settings.py', '09': 'settings.py',
            '10': 'auto_repair.py'
        }
        if choice in mapping: run_script(mapping[choice])
        elif choice == '0': continue
        elif choice in ['*', 'x', 'exit', 'q']:
            print(f"\n{C_RED}Exiting Trace Spyder Terminal Hub. Goodbye!{C_RESET}\n")
            sys.exit(0)
        else: input(f"\n{C_RED}❌ Invalid choice! Press Enter...{C_RESET}")

if __name__ == "__main__": main_menu()
