@echo off
title Trace Spyder Hub - Windows Platform Installer
color 0b
cls

echo ============================================================
echo      TRACE SPYDER TERMINAL HUB - WINDOWS PC SETUP
echo ============================================================
echo.
echo [?] Where are you installing this suite?
echo   [1] Windows Laptop / PC
echo   [2] Android Mobile (Termux)
echo ------------------------------------------------------------
set /p plat_choice="➤ Select Platform (1 or 2): "

if "%plat_choice%"=="2" (
    echo.
    echo [*] To install on Android, run 'bash ~/installer.sh' in Termux.
    pause
    exit /b
)

echo.
echo [*] Checking Windows Dependencies...

:: 1. Check Python
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [*] Installing Python via Winget...
    winget install Python.Python.3.11 --silent --accept-package-agreements --accept-source-agreements
    echo [✓] Python Installed.
) else (
    echo [✓] Python is detected.
)

:: 2. Check FFmpeg
ffmpeg -version >nul 2>&1
if %errorlevel% neq 0 (
    echo [*] Installing FFmpeg via Winget...
    winget install Gyan.FFmpeg --silent --accept-package-agreements --accept-source-agreements
    echo [✓] FFmpeg Installed.
) else (
    echo [✓] FFmpeg is detected.
)

:: 3. Check and Install Libraries
echo [*] Configuring Python modules...
python -m pip install --upgrade pip >nul 2>&1
python -m pip install requests yt-dlp spotdl telethon pillow qrcode cryptography speedtest-cli >nul 2>&1

echo.
echo ============================================================
echo [✓] WINDOWS ENVIRONMENT READY! LAUNCHING HUB...
echo ============================================================
timeout /t 2 >nul
cls

python menu.py
pause
