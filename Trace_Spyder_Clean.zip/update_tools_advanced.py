import os

BANNER = r'''
\033[1;36m┌────────────────────────────────────────────────────────────┐
\033[1;37m  ████████╗██████╗  █████╗  ██████╗███████╗
  ╚══██╔══╝██╔══██╗██╔══██╗██╔════╝██╔════╝
     ██║   ██████╔╝███████║██║     █████╗  
     ██║   ██╔══██╗██╔══██║██║     ██╔══╝  
     ██║   ██║  ██║██║  ██║╚██████╗███████╗
     ╚═╝   ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚══════╝

  ███████╗██████╗ ██╗   ██╗██████╗ ███████╗██████╗ 
  ██╔════╝██╔══██╗╚██╗ ██╔╝██╔══██╗██╔════╝██╔══██╗
  ███████╗██████╔╝ ╚████╔╝ ██║  ██║█████╗  ██████╔╝
  ╚════██║██╔═══╝   ╚██╔╝  ██║  ██║██╔══╝  ██╔══██╗
  ███████║██║        ██║   ██████╔╝███████╗██║  ██║
  ╚══════╝╚═╝        ╚═╝   ╚═════╝ ╚══════╝╚═╝  ╚═╝
\033[0m
             \033[1;33m🕷️  \033[1;36mT R A C E   S P Y D E R\033[1;33m  🕷️\033[0m
           \033[1;35m⚡ ═ \033[1;32mT E R M I N A L   H U B\033[1;35m ═ ⚡\033[0m
\033[1;36m└────────────────────────────────────────────────────────────┘\033[0m
'''

tools_code = f'''import os, sys, asyncio

C_CYAN = "\\033[1;36m"
C_GREEN = "\\033[1;32m"
C_YELLOW = "\\033[1;33m"
C_RED = "\\033[1;31m"
C_MAGENTA = "\\033[1;35m"
C_WHITE = "\\033[1;37m"
C_RESET = "\\033[0m"

BANNER = """{BANNER}"""
SESSION_PATH = os.path.expanduser("~/.tg_user_session")

def clear_screen():
    os.system('clear')
    print(BANNER)
    print(f"{{C_MAGENTA}}  [▸] ACTIVE MODULE : {{C_GREEN}}TELEGRAM CHAT EXPLORER & CLOUD HUB{{C_RESET}}")
    print(f"{{C_CYAN}}─"*60 + f"{{C_RESET}}")

def get_client():
    from telethon import TelegramClient
    api_id = 2040
    api_hash = "b18441a1ff607e10a989891a5462e627"
    return TelegramClient(SESSION_PATH, api_id, api_hash)

async def select_target_chat(client):
    clear_screen()
    dialogs = []
    print(f"{{C_YELLOW}}[*] Loading your recent 15 chats...{{C_RESET}}")
    async for dialog in client.iter_dialogs(limit=15):
        dialogs.append(dialog)

    print(f"\\n{{C_CYAN}}╔══════════════════ [ RECENT CHATS (15) ] ══════════════════╗{{C_RESET}}")
    for idx, d in enumerate(dialogs):
        name = d.name if d.name else "Saved Messages / Unknown"
        print(f"  {C_YELLOW}[{idx+1:02d}]{C_RESET} {name[:45]}")
    print(f"{{C_CYAN}}╚════════════════════════════════════════════════════════════╝{{C_RESET}}")
    print(f"  {C_MAGENTA}[s]{C_RESET} Search User / Group by Name or Username")
    print(f"  {C_RED}[#]{C_RESET} Back to Menu")
    print(f"{{C_CYAN}}─"*60 + f"{{C_RESET}}")

    c = input(f"{{C_GREEN}}➤ Select Chat (1-15) or [s] Search: {{C_RESET}}").strip().lower()
    
    if c == 's':
        query = input(f"{{C_YELLOW}}Enter Name / @Username to search: {{C_RESET}}").strip()
        if not query:
            return None
        try:
            entity = await client.get_entity(query)
            return entity, getattr(entity, 'title', None) or getattr(entity, 'first_name', query)
        except Exception as e:
            print(f"{{C_RED}}❌ User/Chat not found: {{e}}{{C_RESET}}")
            input("Press Enter...")
            return None
    elif c.isdigit() and 1 <= int(c) <= len(dialogs):
        selected = dialogs[int(c)-1]
        return selected.entity, selected.name or "Saved Messages"
    return None

async def manage_chat_session():
    client = get_client()
    await client.start()

    res = await select_target_chat(client)
    if not res:
        await client.disconnect()
        return

    entity, chat_name = res

    while True:
        clear_screen()
        print(f"{{C_YELLOW}}[*] Active Chat: {{C_CYAN}}{{chat_name}}{{C_RESET}}")
        print(f"{{C_YELLOW}}[*] Fetching last 25 messages...{{C_RESET}}\\n")

        messages = []
        async for msg in client.iter_messages(entity, limit=25):
            messages.append(msg)

        messages.reverse()

        print(f"{{C_CYAN}}────────────────── [ LAST 25 MESSAGES ] ──────────────────{{C_RESET}}")
        media_count = 0
        for m in messages:
            sender = "Me" if m.out else "Them"
            text_preview = m.text.replace('\\n', ' ')[:40] if m.text else ""
            
            if m.media:
                media_count += 1
                fname = getattr(m.file, 'name', None) or f"[Media/File ID:{m.id}]"
                print(f"  {C_MAGENTA}[{sender}]{C_RESET} {C_YELLOW}📁 {fname}{C_RESET} {text_preview}")
            else:
                print(f"  {C_MAGENTA}[{sender}]{C_RESET} {text_preview if text_preview else '[Empty]'}")

        print(f"{{C_CYAN}}────────────────────────────────────────────────────────────{{C_RESET}}")
        print(f"  {C_CYAN}[1]{C_RESET} Export / Send File to this Chat")
        print(f"  {C_CYAN}[2]{C_RESET} Import / Download Files from this Chat ({media_count} files available)")
        print(f"  {C_YELLOW}[0]{C_RESET} Refresh Messages")
        print(f"  {C_RED}[#]{C_RESET} Back to Chats List")
        print(f"{{C_CYAN}}═"*60 + f"{{C_RESET}}")

        act = input(f"{{C_GREEN}}➤ Select Action ([1]/[2]/[0]/[#]): {{C_RESET}}").strip().lower()

        if act == '1':
            fpath = input(f"\\n{{C_GREEN}}➤ Enter full path of file to upload: {{C_RESET}}").strip()
            if os.path.exists(fpath):
                print(f"{{C_YELLOW}}[*] Uploading {{os.path.basename(fpath)}}...{{C_RESET}}")
                await client.send_file(entity, fpath, caption="🚀 Exported from Trace Spyder Terminal Hub")
                print(f"{{C_GREEN}}✅ Sent successfully!{{C_RESET}}")
            else:
                print(f"{{C_RED}}❌ File not found!{{C_RESET}}")
            input("Press Enter to continue...")

        elif act == '2':
            media_msgs = [m for m in messages if m.media]
            if not media_msgs:
                print(f"\\n{{C_RED}}❌ No downloadable files found in the recent messages!{{C_RESET}}")
                input("Press Enter...")
                continue

            print(f"\\n{{C_CYAN}}Files available to download:{{C_RESET}}")
            for i, m in enumerate(media_msgs):
                fname = getattr(m.file, 'name', None) or f"media_{m.id}"
                fsize = getattr(m.file, 'size', 0) / (1024*1024)
                print(f"  [{i+1}] {fname} ({fsize:.2f} MB)")

            fchoice = input(f"\\n{{C_GREEN}}➤ Select file number to download (1-{{len(media_msgs)}}): {{C_RESET}}").strip()
            if fchoice.isdigit() and 1 <= int(fchoice) <= len(media_msgs):
                sel_m = media_msgs[int(fchoice)-1]
                out_dir = "/sdcard/Download"
                print(f"{{C_YELLOW}}[*] Downloading into {{out_dir}}...{{C_RESET}}")
                path = await sel_m.download_media(file=out_dir)
                print(f"{{C_GREEN}}✅ Download completed: {{path}}{{C_RESET}}")
            else:
                print(f"{{C_RED}}❌ Invalid selection!{{C_RESET}}")
            input("Press Enter to continue...")

        elif act == '0':
            continue
        elif act in ['#', 'b', 'back']:
            break

    await client.disconnect()

def main():
    while True:
        clear_screen()
        print(f"  {{C_CYAN}}[01]{{C_RESET}} Open Telegram Chat Explorer (15 Chats / Search / History)")
        print(f"  {{C_CYAN}}[02]{{C_RESET}} Logout / Switch Telegram Account")
        print(f"{{C_CYAN}}─"*60 + f"{{C_RESET}}")
        print(f"  {{C_CYAN}[#]{{C_RESET}} Back to Main Menu")
        print(f"  {{C_RED}}[*]{{C_RESET}} Full Exit to Terminal")
        print(f"{{C_CYAN}}═"*60 + f"{{C_RESET}}")
        c = input(f"{{C_GREEN}}➤ Option: {{C_RESET}}").strip().lower()
        if c in ['1', '01']:
            asyncio.run(manage_chat_session())
        elif c in ['2', '02']:
            sess = SESSION_PATH + ".session"
            if os.path.exists(sess):
                os.remove(sess)
                print(f"\\n{{C_GREEN}}✅ Account logged out successfully!{{C_RESET}}")
            else:
                print(f"\\n{{C_YELLOW}}[*] No active session found.{{C_RESET}}")
            input("\\nPress Enter to continue...")
        elif c in ['#', 'b', 'back']:
            break
        elif c in ['*', 'x', 'exit', 'q']:
            os._exit(0)

if __name__ == "__main__":
    main()
'''

with open(os.path.expanduser("~/tools.py"), "w") as f:
    f.write(tools_code)

print("✅ Updated: Full Chat Explorer, 15 Chats list, User Search & 25 Messages Viewer ready!")
