import phonenumbers
from phonenumbers import geocoder, carrier, timezone

raw_number = input("Enter phone number with country code (e.g., +91...): ")
parsed_number = phonenumbers.parse(raw_number)

# വിവരങ്ങൾ പ്രിന്റ് ചെയ്യുന്നു
print("--------------------------------")
print("Valid Number:", phonenumbers.is_valid_number(parsed_number))
print("Country / Region:", geocoder.description_for_number(parsed_number, "en"))
print("Service Provider:", carrier.name_for_number(parsed_number, "en"))
print("Time Zone:", timezone.time_zones_for_number(parsed_number))
print("--------------------------------")

