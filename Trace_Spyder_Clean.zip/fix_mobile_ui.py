import os

# Mobile Perfect Responsive Banner (Width: 48 Chars)
MOBILE_BANNER = """\033[1;36m┌──────────────────────────────────────────────┐
\033[1;37m   ████████╗██████╗  █████╗  ██████╗███████╗
   ╚══██╔══╝██╔══██╗██╔══██╗██╔════╝██╔════╝
      ██║   ██████╔╝███████║██║     █████╗  
      ██║   ██╔══██╗██╔══██║██║     ██╔══╝  
      ██║   ██║  ██║██║  ██║╚██████╗███████╗
      ╚═╝   ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚══════╝

   ███████╗██████╗ ██╗   ██╗██████╗ ███████╗
   ██╔════╝██╔══██╗╚██╗ ██╔╝██╔══██╗██╔════╝
   ███████╗██████╔╝ ╚████╔╝ ██║  ██║█████╗  
   ╚════██║██╔═══╝   ╚██╔╝  ██║  ██║██╔══╝  
   ███████║██║        ██║   ██████╔╝███████╗
   ╚══════╝╚═╝        ╚═╝   ╚═════╝ ╚══════╝
\033[0m
          \033[1;33m🕷️ \033[1;36mGOWRISANKAR B\033[1;33m 🕷️\033[0m
            \033[1;35m⚡ \033[1;32mTERMINAL HUB\033[1;35m ⚡\033[0m
\033[1;36m└──────────────────────────────────────────────┘\033[0m"""

# 1. Responsive menu.py
menu_content = f'''import os, sys, subprocess

C_CYAN = "\\033[1;36m"
C_GREEN = "\\033[1;32m"
C_YELLOW = "\\033[1;33m"
C_RED = "\\033[1;31m"
C_MAGENTA = "\\033[1;35m"
C_WHITE = "\\033[1;37m"
C_RESET = "\\033[0m"

BANNER = """{MOBILE_BANNER}"""

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')
    print(BANNER)
    print(f"{{C_MAGENTA}} [▸] ACTIVE : {{C_GREEN}}MAIN DASHBOARD{{C_RESET}}")
    print(f"{{C_CYAN}}────────────────────────────────────────────────{{C_RESET}}")

def run_script(script_name):
    path = os.path.expanduser(f"~/{{script_name}}")
    if os.path.exists(path):
        subprocess.run([sys.executable, path])
    else:
        print(f"\\n{{C_RED}}❌ Not found: {{script_name}}{{C_RESET}}")
        input("Press Enter...")

def main_menu():
    while True:
        clear_screen()
        print(f"  {{C_YELLOW}}─── [ CORE ENGINES (A-Z) ] ───{{C_RESET}}")
        print(f"  {{C_CYAN}}[01]{{C_RESET}} Archive ZIP Master Engine")
        print(f"  {{C_CYAN}[02]{{C_RESET}} Cyber Encoder & Decoder")
        print(f"  {{C_CYAN}[03]{{C_RESET}} Cyber Port Scanner & Recon")
        print(f"  {{C_CYAN}[04]{{C_RESET}} Device & Battery Diagnostic")
        print(f"  {{C_CYAN}[05]{{C_RESET}} Encrypted Terminal Notes")
        print(f"  {{C_CYAN}[06]{{C_RESET}} File Security Vault (AES-256)")
        print(f"  {{C_CYAN}[07]{{C_RESET}} Hash Generator & Cracker")
        print(f"  {{C_CYAN}[08]{{C_RESET}} Link Expander & Safety Trace")
        print(f"  {{C_CYAN}[09]{{C_RESET}} Live Crypto & Currency Ticker")
        print(f"  {{C_CYAN}[10]{{C_RESET}} Media & Document Converter")
        print(f"  {{C_CYAN}[11]{{C_RESET}} Network Speedtest & IP Info")
        print(f"  {{C_CYAN}[12]{{C_RESET}} Password & Token Generator")
        print(f"  {{C_CYAN}[13]{{C_RESET}} QR Code Engine (View & Save)")
        print(f"  {{C_CYAN}[14]{{C_RESET}} Seeker OSINT Location Explorer")
        print(f"  {{C_CYAN}[15]{{C_RESET}} Spotify Music/Video Puller")
        print(f"  {{C_CYAN}[16]{{C_RESET}} System Auto Repair Diagnostics")
        print(f"  {{C_CYAN}[17]{{C_RESET}} System CPU & RAM Benchmark")
        print(f"  {{C_CYAN}[18]{{C_RESET}} Telegram Cloud Multi-Sync")
        print(f"  {{C_CYAN}[19]{{C_RESET}} Temp Email & Live Inbox Engine")
        print(f"  {{C_CYAN}[20]{{C_RESET}} TeraBox Fast Stream Downloader")
        print(f"  {{C_CYAN}[21]{{C_RESET}} Termux Storage & Cache Purger")
        print(f"  {{C_CYAN}[22]{{C_RESET}} Universal Media Downloader")
        print(f"  {{C_CYAN}[23]{{C_RESET}} Web Headers & Security Recon")
        print(f"{{C_CYAN}}────────────────────────────────────────────────{{C_RESET}}")
        print(f"  {{C_MAGENTA}}⚙️  [24] CONTROL SETTINGS HUB{{C_RESET}}")
        print(f"  {{C_YELLOW}}🌟 [25] ABOUT TRACE SPYDER (MANUAL){{C_RESET}}")
        print(f"{{C_CYAN}}────────────────────────────────────────────────{{C_RESET}}")
        print(f"  {{C_YELLOW}}[00]{{C_RESET}} Refresh Dashboard   {{C_RED}}[*]{{C_RESET}} Exit Terminal")
        print(f"{{C_CYAN}}════════════════════════════════════════════════{{C_RESET}}")

        choice = input(f"{{C_GREEN}}➤ Option (1-25): {{C_RESET}}").strip().lower()
        mapping = {{
            '1': 'zip_master.py', '01': 'zip_master.py',
            '2': 'encoder_tool.py', '02': 'encoder_tool.py',
            '3': 'recon_tool.py', '03': 'recon_tool.py',
            '4': 'device_info.py', '04': 'device_info.py',
            '5': 'notes_tool.py', '05': 'notes_tool.py',
            '6': 'file_vault.py', '06': 'file_vault.py',
            '7': 'hash_tool.py', '07': 'hash_tool.py',
            '8': 'link_unshort.py', '08': 'link_unshort.py',
            '9': 'crypto_tool.py', '09': 'crypto_tool.py',
            '10': 'converter.py',
            '11': 'net_tools.py',
            '12': 'pwgen_tool.py',
            '13': 'qr_tool.py',
            '14': 'seeker_hub.py',
            '15': 'spotify_dl.py',
            '16': 'auto_repair.py',
            '17': 'benchmark_tool.py',
            '18': 'tools.py',
            '19': 'temp_mail.py',
            '20': 'terabox_dl.py',
            '21': 'phone_cleaner.py',
            '22': 'media_dl.py',
            '23': 'web_recon.py',
            '24': 'settings.py',
            '25': 'about.py'
        }}
        if choice in mapping:
            run_script(mapping[choice])
        elif choice in ['0', '00']:
            continue
        elif choice in ['*', 'x', 'exit', 'q']:
            print(f"\\n{{C_RED}}Exiting Trace Spyder. Goodbye!{{C_RESET}}\\n")
            sys.exit(0)
        else:
            input(f"\\n{{C_RED}}❌ Invalid Choice! Press Enter...{{C_RESET}}")

if __name__ == "__main__":
    main_menu()
'''

# 2. Responsive about.py with Auto Text Wrapping (No screen overflow)
about_content = f'''import os, sys, textwrap

C_CYAN = "\\033[1;36m"
C_GREEN = "\\033[1;32m"
C_YELLOW = "\\033[1;33m"
C_RED = "\\033[1;31m"
C_MAGENTA = "\\033[1;35m"
C_WHITE = "\\033[1;37m"
C_RESET = "\\033[0m"

BANNER = """{MOBILE_BANNER}"""

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')
    print(BANNER)
    print(f"{{C_MAGENTA}} [▸] ACTIVE : {{C_GREEN}}DETAILED SYSTEM MANUAL{{C_RESET}}")
    print(f"{{C_CYAN}}────────────────────────────────────────────────{{C_RESET}}")

def print_wrapped(text, width=44, indent="  "):
    for line in text.split('\\n'):
        wrapped = textwrap.fill(line, width=width, initial_indent=indent, subsequent_indent=indent)
        print(f"{{C_WHITE}}{{wrapped}}{{C_RESET}}")

DOCS_EN = [
    ("Archive ZIP Master", "Compression & Unlocker", 
     "• Creates high-compression ZIP files.\\n• Extracts standard & protected archives.\\n• Multi-threaded Brute-Force & Wordlist recovery for lost passwords."),
    ("Cyber Encoder & Decoder", "Multi-Format Converter", 
     "• Converts text between Base64, Hexadecimal, and URL encoding instantly."),
    ("Cyber Port Scanner & Recon", "Network Port Scanner", 
     "• Fast low-latency scanner identifying open TCP service ports (SSH, HTTP, MySQL, etc.)."),
    ("Device Battery Diagnostics", "Hardware Status Monitor", 
     "• Live hardware telemetry, battery level tracking, and accurate partition storage metrics."),
    ("Encrypted Terminal Notes", "CLI Secure Diary", 
     "• Local timestamped private note keeper with zero external exposure."),
    ("File Security Vault", "AES-256 Military Encryptor", 
     "• Password-derived AES-256 cryptography locking files securely and wiping raw originals."),
    ("Hash Generator & Cracker", "Cryptographic Hasher", 
     "• Generates MD5, SHA1, SHA256, and SHA512 hashes instantly for integrity audits."),
    ("Link Safety Unshortener", "URL Redirect Resolver", 
     "• Traces hidden destinations behind short links (bit.ly, tinyurl) without opening browser exploits."),
    ("Live Crypto & Currency", "Real-Time Pricing Ticker", 
     "• Live global market updates for Bitcoin, Ethereum, Solana, and Fiat exchange rates."),
    ("Media Document Converter", "FFmpeg Engine", 
     "• Fast video conversion, 320kbps MP3 ripping, PDF to Image, and Image to PDF creation."),
    ("Network Speedtest & IP", "Bandwidth & Geo Analyzer", 
     "• Real-time Download, Upload, and Ping testing with public WAN IP intelligence."),
    ("Password & Token Generator", "Key Creator", 
     "• Generates high-entropy random passwords and cryptographic Hex API keys."),
    ("QR Code Terminal Engine", "ASCII & Image Generator", 
     "• Renders ASCII QR directly on terminal screen and exports clean PNG images."),
    ("Seeker OSINT Explorer", "Precision Geolocation", 
     "• Advanced OSINT reconnaissance framework coordination via sensor hooks."),
    ("Spotify Smart Downloader", "Lossless Audio Grabber", 
     "• Downloads Spotify tracks, full albums, and canvas loops with 320kbps audio quality."),
    ("System Auto-Repair Engine", "Self-Healing Maintenance", 
     "• Fixes permission faults, repairs /tmp paths, and auto-installs missing dependencies."),
    ("System CPU & RAM Benchmark", "Hardware Stress Tester", 
     "• Multi-threaded arithmetic CPU stress test calculating precise hardware capability score."),
    ("Telegram Cloud Hub", "Multi-Account Sync", 
     "• Direct terminal login to download and upload files with real-time speedometers."),
    ("Temporary Email & Inbox", "Disposable Mail Service", 
     "• Instant throwaway mailboxes to receive OTP verification codes without spam risks."),
    ("TeraBox Fast Downloader", "High-Speed Streamer", 
     "• Bypasses bandwidth throttles to download TeraBox videos at maximum network speed."),
    ("Storage & Cache Purger", "System & App Cleaner", 
     "• Deep purges Python bytecache, app logs, and temporary junk files to reclaim free storage."),
    ("Universal Media Downloader", "Multi-Platform yt-dlp", 
     "• Downloads videos and reels from YouTube, Instagram, Facebook, and X with live speed meters."),
    ("Web Headers & Recon", "HTTP Security Inspector", 
     "• Inspects HTTP headers, cookies, and server flags for any domain safely.")
]

DOCS_ML = [
    ("Archive ZIP Master", "കംപ്രഷൻ & അൺലോക്കർ", 
     "• ഫയലുകൾ ZIP ആക്കാനും സുരക്ഷിതമായി എക്സ്ട്രാക്റ്റ് ചെയ്യാനും സഹായിക്കുന്നു.\\n• പാസ്‌വേഡ് മറന്നുപോയ ZIP ഫയലുകൾ അൺലോക്ക് ചെയ്യാൻ സ്മാർട്ട് ബ്രൂട്ട്-ഫോഴ്സ് സൗകര്യം."),
    ("Cyber Encoder & Decoder", "ഡാറ്റാ എൻകോഡിംഗ്", 
     "• Base64, Hexadecimal, URL എൻകോഡിംഗ് വഴികളിലേക്ക് മാറ്റാനും തിരിച്ച് ഡീകോഡ് ചെയ്യാനും."),
    ("Cyber Port Scanner & Recon", "നെറ്റ്‌വർക്ക് പോർട്ട് സ്കാനർ", 
     "• സെർവറുകളിലെ ഓപ്പൺ പോർട്ടുകൾ (SSH, HTTP, MySQL മുതലായവ) വേഗത്തിൽ കണ്ടെത്തുന്നു."),
    ("Device Battery Diagnostics", "സിസ്റ്റം ഹാർഡ്‌വെയർ മോണിറ്റർ", 
     "• ബാറ്ററി ചാർജ്, ഹാർഡ്‌വെയർ താപനില, റാം, മെമ്മറി സ്റ്റോറേജ് എന്നിവ തത്സമയം അറിയാൻ."),
    ("Encrypted Terminal Notes", "രഹസ്യ നോട്ട്പാഡ്", 
     "• കുറിപ്പുകളും പ്രധാന ഡാറ്റകളും ടൈംസ്റ്റാമ്പോടെ സുരക്ഷിതമായി ടെർമിനലിൽ സൂക്ഷിക്കാം."),
    ("File Security Vault", "AES-256 ഫയൽ ലോക്കർ", 
     "• ഫയലുകളും ചിത്രങ്ങളും AES-256 എൻക്രിപ്ഷൻ വഴി പാസ്‌വേഡ് ഉപയോഗിച്ച് സുരക്ഷിതമായി പൂട്ടാൻ."),
    ("Hash Generator & Cracker", "ഹാഷ് ടൂൾകിറ്റ്", 
     "• MD5, SHA1, SHA256, SHA512 ഹാഷുകൾ തൽക്ഷണം നിർമ്മിച്ച് പരിശോധിക്കാൻ."),
    ("Link Safety Unshortener", "ലിങ്ക് സുരക്ഷാ സ്കാനർ", 
     "• bit.ly, tinyurl തുടങ്ങിയ ഷോർട്ട് ലിങ്കുകളുടെ ഒറിജിനൽ വിലാസം സുരക്ഷിതമായി കണ്ടെത്താൻ."),
    ("Live Crypto & Currency", "ലൈവ് ക്രിപ്റ്റോ ടിക്ക്", 
     "• Bitcoin, Ethereum എന്നിവയുടെ തത്സമയ മാർക്കറ്റ് വിലകളും രൂപയിലെ (INR) മൂല്യവും അറിയാൻ."),
    ("Media Document Converter", "FFmpeg കൺവേർട്ടർ", 
     "• വീഡിയോ കൺവേർഷൻ, 320kbps MP3 ഓഡിയോ എക്സ്ട്രാക്ഷൻ, PDF നിർമ്മാണം എന്നിവ നടത്താൻ."),
    ("Network Speedtest & IP", "സ്പീഡ് & IP ഇൻഫോ", 
     "• ഡൗൺലോഡ്/അപ്‌ലോഡ് സ്പീഡ്, പിംഗ്, പബ്ലിക് IP ലൊക്കേഷൻ എന്നിവ കൃത്യമായി അളക്കാൻ."),
    ("Password & Token Generator", "പാസ്‌വേഡ് നിർമ്മാതാവ്", 
     "• ഹാക്ക് ചെയ്യാൻ പറ്റാത്ത ശക്തമായ റാൻഡം പാസ്‌വേഡുകളും API ടോക്കണുകളും ഉണ്ടാക്കാൻ."),
    ("QR Code Terminal Engine", "ടെർമിനൽ QR ജനറേറ്റർ", 
     "• സ്ക്രീനിൽ തന്നെ സ്കാൻ ചെയ്യാൻ സാധിക്കുന്ന ASCII QR കോഡുകൾ നിർമ്മിക്കാനും സേവ് ചെയ്യാനും."),
    ("Seeker OSINT Explorer", "ലൊക്കേഷൻ ടൂൾ", 
     "• ലൊക്കേഷൻ സെൻസർ ഹുക്കുകൾ വഴി കൃത്യമായ സ്ഥലം കണ്ടെത്താൻ സഹായിക്കുന്ന OSINT ടൂൾ."),
    ("Spotify Smart Downloader", "സ്പോട്ടിഫൈ ഡൗൺലോഡർ", 
     "• സ്പോട്ടിഫൈ പാട്ടുകൾ, ആൽബങ്ങൾ, വീഡിയോകൾ എന്നിവ 320kbps ക്വാളിറ്റിയിൽ ഡൗൺലോഡ് ചെയ്യാൻ."),
    ("System Auto-Repair Engine", "ഓട്ടോ-റിപ്പയർ എഞ്ചിൻ", 
     "• കേടായ പാത്തുകൾ, ലൈബ്രറികൾ, പെർമിഷനുകൾ എന്നിവ തനിയെ പരിശോധിച്ച് പരിഹരിക്കുന്നു."),
    ("System CPU & RAM Benchmark", "പെർഫോമൻസ് ടെസ്റ്റർ", 
     "• ഫോണിന്റെ/ലാപ്ടോപ്പിന്റെ CPU സ്പീഡ് സ്കോർ ലൈവായി അളക്കുന്ന ബെഞ്ച്മാർക്ക് ടൂൾ."),
    ("Telegram Cloud Hub", "ടെലിഗ്രാം ഫയൽ സിങ്ക്", 
     "• ലൈവ് സ്പീഡിൽ ടെലിഗ്രാം ഫയലുകൾ അയക്കാനും ഡൗൺലോഡ് ചെയ്യാനും മൾട്ടി-അക്കൗണ്ട് മാനേജ് ചെയ്യാനും."),
    ("Temporary Email & Inbox", "താല്കാലിക ഇമെയിൽ", 
     "• OTP-കളും വെരിഫിക്കേഷൻ സന്ദേശങ്ങളും സ്വീകരിക്കാൻ തത്സമയ ഡിസ്പോസബിൾ ഇമെയിൽ നൽകുന്നു."),
    ("TeraBox Fast Downloader", "ടെറാബോക്സ് ഡൗൺലോഡർ", 
     "• വേഗത നിയന്ത്രണങ്ങൾ ഇല്ലാതെ ടെറാബോക്സ് വീഡിയോകൾ പരമാവധി സ്പീഡിൽ ഡൗൺലോഡ് ചെയ്യാൻ."),
    ("Storage & Cache Purger", "കാഷെ & ജങ്ക് ക്ലീനർ", 
     "• പൈത്തൺ കാഷെ, ആപ്പ് ലോഗുകൾ എന്നിവ നീക്കം ചെയ്ത് ഫോൺ സ്റ്റോറേജ് വർദ്ധിപ്പിക്കാൻ."),
    ("Universal Media Downloader", "മീഡിയ ഡൗൺലോഡർ", 
     "• YouTube, Instagram, Facebook, X വീഡിയോകൾ തത്സമയ സ്പീഡ് മീറ്ററോടെ ഡൗൺലോഡ് ചെയ്യാൻ."),
    ("Web Headers & Recon", "വെബ് ഇൻസ്പെക്ടർ", 
     "• വെബ്‌സൈറ്റുകളുടെ സെർവർ ഹെഡറുകളും സുരക്ഷാ ഫ്ലാഗുകളും സുരക്ഷിതമായി സ്കാൻ ചെയ്യാൻ.")
]

def show_manual(docs, lang_name):
    while True:
        clear_screen()
        print(f"{{C_YELLOW}}─── [ 🌟 MANUAL : {{lang_name}} ] ───{{C_RESET}}")
        for idx, (name, subtitle, _) in enumerate(docs):
            print(f" {{C_CYAN}}[{{idx+1:02d}}]{{C_RESET}} {{C_GREEN}}{{name:<26}}{{C_RESET}}")
        print(f"{{C_CYAN}}────────────────────────────────────────────────{{C_RESET}}")
        print(f"  {{C_YELLOW}}[A]{{C_RESET}} View All Modules    {{C_CYAN}}[#]{{C_RESET}} Back")
        print(f"{{C_CYAN}}════════════════════════════════════════════════{{C_RESET}}")

        c = input(f"{{C_GREEN}}➤ Select Module (1-{{len(docs)}}) or Action: {{C_RESET}}").strip().lower()
        if c in ['#', 'b', 'back']: break
        elif c == 'a':
            for name, subtitle, details in docs:
                clear_screen()
                print(f"{{C_YELLOW}}MODULE  : {{C_GREEN}}{{name}}{{C_RESET}}")
                print(f"{{C_YELLOW}}PURPOSE : {{C_WHITE}}{{subtitle}}{{C_RESET}}")
                print(f"{{C_CYAN}}────────────────────────────────────────────────{{C_RESET}}")
                print_wrapped(details)
                print(f"{{C_CYAN}}────────────────────────────────────────────────{{C_RESET}}")
                input(f"{{C_YELLOW}}Press Enter for next module...{{C_RESET}}")
        elif c.isdigit() and 1 <= int(c) <= len(docs):
            name, subtitle, details = docs[int(c)-1]
            clear_screen()
            print(f"{{C_YELLOW}}MODULE  : {{C_GREEN}}{{name}}{{C_RESET}}")
            print(f"{{C_YELLOW}}PURPOSE : {{C_WHITE}}{{subtitle}}{{C_RESET}}")
            print(f"{{C_CYAN}}────────────────────────────────────────────────{{C_RESET}}")
            print_wrapped(details)
            print(f"{{C_CYAN}}────────────────────────────────────────────────{{C_RESET}}")
            input(f"{{C_YELLOW}}Press Enter to return...{{C_RESET}}")

def main():
    while True:
        clear_screen()
        print(f"  {{C_YELLOW}}─── [ 🌐 SELECT MANUAL LANGUAGE ] ───{{C_RESET}}")
        print(f"  {{C_CYAN}}[1]{{C_RESET}} English (Mobile Screen Optimized)")
        print(f"  {{C_CYAN}[2]{{C_RESET}} മലയാളം (മൊബൈൽ സ്ക്രീൻ ഒപ്റ്റിമൈസ്ഡ്)")
        print(f"{{C_CYAN}}────────────────────────────────────────────────{{C_RESET}}")
        print(f"  {{C_CYAN}}[#]{{C_RESET}} Back to Main Dashboard")
        print(f"{{C_CYAN}}════════════════════════════════════════════════{{C_RESET}}")

        c = input(f"{{C_GREEN}}➤ Choose (1-2): {{C_RESET}}").strip().lower()
        if c == '1': show_manual(DOCS_EN, "ENGLISH")
        elif c == '2': show_manual(DOCS_ML, "MALAYALAM")
        elif c in ['#', 'b', 'back']: break

if __name__ == "__main__":
    main()
'''

with open(os.path.expanduser("~/menu.py"), "w") as f:
    f.write(menu_content)

with open(os.path.expanduser("~/about.py"), "w") as f:
    f.write(about_content)

print("✅ Mobile Responsive Design & Text-Wrapping applied successfully!")
