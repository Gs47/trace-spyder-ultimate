import os, sys, subprocess, shutil, glob, time

C_CYAN = "\033[1;36m"
C_GREEN = "\033[1;32m"
C_YELLOW = "\033[1;33m"
C_RED = "\033[1;31m"
C_MAGENTA = "\033[1;35m"
C_WHITE = "\033[1;37m"
C_RESET = "\033[0m"

BANNER = """[1;36m┌────────────────────────────────────────────────────────────┐
[1;37m  ████████╗██████╗  █████╗  ██████╗███████╗
  ╚══██╔══╝██╔══██╗██╔══██╗██╔════╝██╔════╝
     ██║   ██████╔╝███████║██║     █████╗  
     ██║   ██╔══██╗██╔══██║██║     ██╔══╝  
     ██║   ██║  ██║██║  ██║╚██████╗███████╗
     ╚═╝   ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚══════╝

  ███████╗██████╗ ██╗   ██╗██████╗ ███████╗██████╗ 
  ██╔════╝██╔══██╗╚██╗ ██╔╝██╔══██╗██╔════╝██╔══██╗
  ███████╗██████╔╝ ╚████╔╝ ██║  ██║█████╗  ██████╔╝
  ╚════██║██╔═══╝   ╚██╔╝  ██║  ██║██╔══╝  ██╔══██╗
  ███████║██║        ██║   ██████╔╝███████╗██║  ██║
  ╚══════╝╚═╝        ╚═╝   ╚═════╝ ╚══════╝╚═╝  ╚═╝
[0m
         [1;33m🕷️  [1;36mG O W R I   S H A N K A R[1;33m  🕷️[0m
           [1;35m⚡ ═ [1;32mT E R M I N A L   H U B[1;35m ═ ⚡[0m
[1;36m└────────────────────────────────────────────────────────────┘[0m"""

def get_download_dir():
    if os.name == 'nt':
        return os.path.join(os.path.expanduser("~"), "Downloads")
    if os.path.exists("/sdcard/Download"):
        return "/sdcard/Download"
    return os.path.expanduser("~/Downloads")

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')
    print(BANNER)
    print(f"{C_MAGENTA}  [▸] ACTIVE MODULE : {C_GREEN}NETWORK SPEEDTEST & IP EXPLORER{C_RESET}")
    print(f"{C_CYAN}─"*60 + f"{C_RESET}")

import requests

def run_speedtest():
    clear_screen()
    print(f"{C_YELLOW}[*] Testing Network Latency, Download & Upload Speed...{C_RESET}")
    print(f"{C_CYAN}─"*60 + f"{C_RESET}")
    try:
        import speedtest
        st = speedtest.Speedtest()
        print(f"[*] Selecting optimal server...")
        st.get_best_server()
        ping = st.results.ping
        print(f"  {C_GREEN}[✓]{C_RESET} Ping Latency : {C_WHITE}{ping:.2f} ms{C_RESET}")
        
        print(f"[*] Testing Download Speed...")
        dl = st.download() / (1024 * 1024)
        print(f"  {C_GREEN}[✓]{C_RESET} Download Speed: {C_YELLOW}{dl:.2f} Mbps{C_RESET}")
        
        print(f"[*] Testing Upload Speed...")
        ul = st.upload() / (1024 * 1024)
        print(f"  {C_GREEN}[✓]{C_RESET} Upload Speed  : {C_MAGENTA}{ul:.2f} Mbps{C_RESET}")
    except Exception as e:
        print(f"{C_RED}❌ Speedtest error: {e}{C_RESET}")
    print(f"{C_CYAN}─"*60 + f"{C_RESET}")
    input("Press Enter to continue...")

def get_ip_info():
    clear_screen()
    print(f"{C_YELLOW}[*] Fetching Public IP & Geolocation Details...{C_RESET}
")
    try:
        r = requests.get("https://ipapi.co/json/", timeout=8).json()
        print(f"  {C_CYAN}Public IP Address :{C_RESET} {C_WHITE}{r.get('ip')}{C_RESET}")
        print(f"  {C_CYAN}ISP / Organization:{C_RESET} {C_WHITE}{r.get('org')}{C_RESET}")
        print(f"  {C_CYAN}City / Region     :{C_RESET} {C_WHITE}{r.get('city')}, {r.get('region')}{C_RESET}")
        print(f"  {C_CYAN}Country           :{C_RESET} {C_WHITE}{r.get('country_name')} ({r.get('country_code')}){C_RESET}")
        print(f"  {C_CYAN}Timezone          :{C_RESET} {C_WHITE}{r.get('timezone')}{C_RESET}")
    except Exception as e:
        print(f"{C_RED}❌ Error fetching IP: {e}{C_RESET}")
    print(f"
{C_CYAN}─"*60 + f"{C_RESET}")
    input("Press Enter to continue...")

def main():
    while True:
        clear_screen()
        print(f"  {C_CYAN}[1]{C_RESET} Live Speedtest (Ping / Download / Upload)")
        print(f"  {C_CYAN}[2]{C_RESET} Public IP & Network Geolocation Details")
        print(f"{C_CYAN}─"*60 + f"{C_RESET}")
        print(f"  {C_CYAN}[#]{C_RESET} Back to Main Menu")
        print(f"  {C_RED}[*]{C_RESET} Full Exit to Terminal")
        print(f"{C_CYAN}═"*60 + f"{C_RESET}")
        c = input(f"{C_GREEN}➤ Select Option (1-2): {C_RESET}").strip().lower()
        if c == '1': run_speedtest()
        elif c == '2': get_ip_info()
        elif c in ['#', 'b', 'back']: break
        elif c in ['*', 'x', 'exit', 'q']: sys.exit(0)

if __name__ == "__main__": main()
