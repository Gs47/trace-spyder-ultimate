import sys, os, time, threading, queue
from telethon.sync import TelegramClient

API_ID = 32918286
API_HASH = 'f888fdba6d829cf210828f8d4b28b783'
DOWNLOAD_DIR = '/sdcard/Download/'

client = TelegramClient('my_session', API_ID, API_HASH)
download_queue = queue.Queue()

last_time = time.time()
last_bytes = 0

def progress_callback(current, total):
    global last_time, last_bytes
    current_time = time.time()
    time_diff = current_time - last_time
    
    if time_diff >= 0.8:
        speed = (current - last_bytes) / time_diff
        eta = (total - current) / speed if speed > 0 else 0
        
        cur_mb = current / (1024 * 1024)
        tot_mb = total / (1024 * 1024)
        pct = (current / total) * 100
        spd_mb = speed / (1024 * 1024)
        
        status = f"\r[DL: {pct:4.1f}%] {cur_mb:.1f}/{tot_mb:.1f}MB | {spd_mb:.2f}MB/s | ETA:{int(eta)}s"
        sys.stdout.write(status.ljust(55))
        sys.stdout.flush()
        
        last_time = current_time
        last_bytes = current

def worker():
    global last_time, last_bytes
    while True:
        msg = download_queue.get()
        if msg is None:
            break
        
        fname = getattr(msg.file, 'name', 'Media_File')
        print(f"\n\n--> Started Downloading: {fname}")
        last_time, last_bytes = time.time(), 0
        
        try:
            client.download_media(msg, file=DOWNLOAD_DIR, progress_callback=progress_callback)
            print(f"\n--> Finished: {fname}\n")
        except Exception as e:
            print(f"\n--> Error downloading {fname}: {e}\n")
            
        download_queue.task_done()

def main():
    client.start()
    
    # ബാക്ക്ഗ്രൗണ്ട് ഡൗൺലോഡ് ത്രെഡ് റൺ ചെയ്യുന്നു
    downloader_thread = threading.Thread(target=worker, daemon=True)
    downloader_thread.start()
    
    print("=== Telegram Background Queue Manager ===")
    dialogs = client.get_dialogs(limit=20)
    for i, d in enumerate(dialogs, 1): 
        print(f"[{i}] {d.name}")
        
    chat_idx = int(input("\nSelect Chat ID: ")) - 1
    chat = dialogs[chat_idx]
    
    msgs = [m for m in client.get_messages(chat.entity, limit=30) if m.media]
    print("\n--- Available Media ---")
    for i, m in enumerate(msgs, 1):
        file_size = (m.file.size / (1024*1024)) if m.file else 0
        file_name = m.file.name if m.file and m.file.name else f"Media_File_{i}"
        print(f"[{i}] {file_name} ({file_size:.1f} MB)")
        
    print("\nTip: Enter file numbers one by one to add them to queue (Type '0' or 'exit' when finished).")
    
    while True:
        val = input("\nEnter File ID to add to Queue: ").strip()
        if val in ['0', 'exit', 'q']:
            print("\nWaiting for all background downloads to complete...")
            break
            
        if val.isdigit():
            idx = int(val) - 1
            if 0 <= idx < len(msgs):
                selected_msg = msgs[idx]
                fname = getattr(selected_msg.file, 'name', f'File_{idx+1}')
                download_queue.put(selected_msg)
                print(f"[+] Added '{fname}' to queue. (Queue size: {download_queue.qsize()})")
            else:
                print("Invalid File ID!")
        else:
            print("Please enter a valid number.")

    download_queue.join()
    print("\nAll downloads in queue finished!")

with client:
    main()

