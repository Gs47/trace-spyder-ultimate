import os, sys

C_CYAN = "\033[1;36m"
C_GREEN = "\033[1;32m"
C_YELLOW = "\033[1;33m"
C_RED = "\033[1;31m"
C_MAGENTA = "\033[1;35m"
C_WHITE = "\033[1;37m"
C_RESET = "\033[0m"

BANNER = f"""{C_CYAN}┌────────────────────────────────────────────────────────────┐
{C_WHITE}  ████████╗██████╗  █████╗  ██████╗███████╗
  ╚══██╔══╝██╔══██╗██╔══██╗██╔════╝██╔════╝
     ██║   ██████╔╝███████║██║     █████╗  
     ██║   ██╔══██╗██╔══██║██║     ██╔══╝  
     ██║   ██║  ██║██║  ██║╚██████╗███████╗
     ╚═╝   ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚══════╝

  ███████╗██████╗ ██╗   ██╗██████╗ ███████╗██████╗ 
  ██╔════╝██╔══██╗╚██╗ ██╔╝██╔══██╗██╔════╝██╔══██╗
  ███████╗██████╔╝ ╚████╔╝ ██║  ██║█████╗  ██████╔╝
  ╚════██║██╔═══╝   ╚██╔╝  ██║  ██║██╔══╝  ██╔══██╗
  ███████║██║        ██║   ██████╔╝███████╗██║  ██║
  ╚══════╝╚═╝        ╚═╝   ╚═════╝ ╚══════╝╚═╝  ╚═╝
{C_RESET}
         {C_YELLOW}🕷️  {C_CYAN}G O W R I   S H A N K A R{C_YELLOW}  🕷️{C_RESET}
           {C_MAGENTA}⚡ ═ {C_GREEN}T E R M I N A L   H U B{C_MAGENTA} ═ ⚡{C_RESET}
{C_CYAN}└────────────────────────────────────────────────────────────┘{C_RESET}"""

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')
    print(BANNER)
    print(f"{C_MAGENTA}  [▸] ACTIVE MODULE : {C_GREEN}ULTIMATE MULTILINGUAL MANUAL{C_RESET}")
    print(f"{C_CYAN}─"*60 + f"{C_RESET}")

DATA_EN = {
    "title": "TRACE SPYDER ULTIMATE MANUAL (ENGLISH)",
    "overview": "Comprehensive documentation for all 23 active engines in Trace Spyder Hub.",
    "tools": [
        ("Archive ZIP Master", "Compression & password recovery engine.", "Compresses folders into ZIP, extracts corrupted archives, and brute-force unlocks password-protected ZIPs."),
        ("Cyber Encoder & Decoder", "Data conversion suite.", "Converts and parses data between Base64, Hexadecimal, and URL encoding standards."),
        ("Cyber Port Scanner & Recon", "Network reconnaissance framework.", "Identifies open TCP ports (SSH/HTTP/MySQL) and host accessibility with low-latency sockets."),
        ("Device Battery Diagnostics", "Hardware telemetry module.", "Monitors RAM usage, exact storage metrics, and hardware battery charge cycles."),
        ("Encrypted Notes Diary", "Local CLI notebook.", "Stores sensitive thoughts and credentials in a timestamped encrypted diary format."),
        ("File Security Vault", "AES-256 local locker.", "Applies military-grade AES encryption to documents, wiping plaintext originals post-encryption."),
        ("Hash Generator & Cracker", "Cryptographic hashing toolkit.", "Generates MD5, SHA1, SHA256, and SHA512 hashes instantly for integrity audits."),
        ("Link Safety Unshortener", "Anti-phishing URL resolver.", "Follows HTTP 301/302 redirects to unmask hidden URLs behind bit.ly, tinyurl, and t.co links."),
        ("Live Crypto & Currency", "Market pricing ticker.", "Fetches real-time price updates for Bitcoin, Ethereum, Solana, and major global fiat currencies."),
        ("Media Document Converter", "FFmpeg-based media pipeline.", "Converts video/audio codecs, compresses files, extracts 320kbps MP3s, and compiles PDFs."),
        ("Network Speed & IP Info", "Bandwidth & geo analyzer.", "Tests real-time download/upload Mbps speed, ping latency, and fetches public WAN IP information."),
        ("Password & Token Generator", "Cryptographic key creator.", "Generates high-entropy random passwords and hex API authentication keys."),
        ("QR Code Terminal Engine", "ASCII matrix visualizer.", "Renders scannable ASCII QR codes inside CLI screens and exports ultra-high-res PNG files."),
        ("Seeker OSINT Explorer", "Geolocation audit framework.", "Coordinates high-precision device location parameters via browser sensor hooks."),
        ("Spotify Smart Downloader", "High-fidelity audio puller.", "Downloads Spotify tracks, albums, and canvas videos with customizable 320k/96k bitrates."),
        ("System Auto-Repair Engine", "Self-healing maintenance.", "Calibrates corrupted /tmp paths, restores executable permissions, and fixes broken pip dependencies."),
        ("System Hardware Benchmark", "CPU stress tester.", "Performs multi-threaded arithmetic workloads to evaluate real-time hardware performance."),
        ("Telegram Cloud Hub", "Multi-account Telegram sync.", "Direct Telethon integration for managing chats, uploading, and downloading files with live speeds."),
        ("Temporary Email & Inbox", "Disposable email engine.", "Provides instant throwaway mailboxes to receive OTP codes and bypass online spam registrations."),
        ("TeraBox Fast Downloader", "Direct-stream engine.", "Bypasses network throttling on TeraBox links to download videos at maximum speed."),
        ("Storage & App Cache Purger", "System & app junk cleaner.", "Deep purges Python bytecode (__pycache__), temporary logs, and package caches."),
        ("Universal Media Downloader", "yt-dlp stream pipeline.", "Downloads reels, shorts, and videos from YouTube, Instagram, Facebook, and X with live speed meters."),
        ("Web Headers & Recon Fetcher", "HTTP security auditor.", "Inspects server response headers, cookies, and HTTP security flags on any domain.")
    ]
}

DATA_ML = {
    "title": "TRACE SPYDER സമഗ്ര വിവരണം (മലയാളം)",
    "overview": "Trace Spyder Hub-ലെ 23 പ്രധാന മൊഡ്യൂളുകളുടെയും പൂർണ്ണമായ ഉപയോഗ വിവരണം താഴെ നൽകുന്നു.",
    "tools": [
        ("Archive ZIP Master", "ഫയൽ കംപ്രഷൻ & അൺലോക്കർ.", "ഫയലുകൾ ZIP ആക്കാനും, കേടുവന്നവ അൺസിപ്പ് ചെയ്യാനും, പാസ്‌വേഡ് ഉള്ള ZIP ഫയലുകൾ ബ്രൂട്ട്-ഫോഴ്സ് വഴി അൺലോക്ക് ചെയ്യാനും സഹായിക്കുന്നു."),
        ("Cyber Encoder & Decoder", "ഡാറ്റാ എൻകോഡിംഗ് ടൂൾ.", "രഹസ്യ വിവരങ്ങൾ Base64, Hexadecimal, URL ഫോർമാറ്റുകളിലേക്ക് മാറ്റാനും തിരിച്ച് ഡീകോഡ് ചെയ്യാനും ഉപയോഗിക്കുന്നു."),
        ("Cyber Port Scanner & Recon", "നെറ്റ്‌വർക്ക് പോർട്ട് സ്കാനർ.", "ഒരു സെർവറിലോ ഐപിയിലോ ഓപ്പൺ ആയി കിടക്കുന്ന പോർട്ടുകൾ (SSH, HTTP, MySQL മുതലായവ) വേഗത്തിൽ കണ്ടെത്തുന്നു."),
        ("Device Battery Diagnostics", "ഹാർഡ്‌വെയർ & ബാറ്ററി മോണിറ്റർ.", "റാം മെമ്മറി, സ്റ്റോറേജ് പാർട്ടീഷനുകൾ, ബാറ്ററി ചാർജിംഗ് നില എന്നിവ കൃത്യതയോടെ ലൈവായി കാണിക്കുന്നു."),
        ("Encrypted Notes Diary", "രഹസ്യ നോട്ട്പാഡ്.", "പ്രധാനപ്പെട്ട കുറിപ്പുകളും വിവരങ്ങളും സുരക്ഷിതമായി ടെർമിനലിൽ തന്നെ ടൈംസ്റ്റാമ്പോടെ സൂക്ഷിക്കാം."),
        ("File Security Vault", "AES-256 ഫയൽ ലോക്കർ.", "രേഖകളും ഫോട്ടോകളും AES-256 പാസ്‌വേഡ് ഉപയോഗിച്ച് എൻക്രിപ്റ്റ് ചെയ്ത് സുരക്ഷിതമാക്കുന്നു."),
        ("Hash Generator & Cracker", "ക്രിപ്റ്റോഗ്രാഫിക് ഹാഷ് ടൂൾ.", "MD5, SHA1, SHA256, SHA512 ഹാഷുകൾ തത്സമയം നിർമ്മിക്കാനും കൃത്യത പരിശോധിക്കാനും സഹായിക്കുന്നു."),
        ("Link Safety Unshortener", "ലിങ്ക് സുരക്ഷാ സ്കാനർ.", "bit.ly, tinyurl തുടങ്ങിയ ഷോർട്ട് ലിങ്കുകൾ തുറക്കാതെ തന്നെ അവയുടെ യഥാർത്ഥ ലക്ഷ്യസ്ഥാനം കണ്ടെത്തുന്നു."),
        ("Live Crypto & Currency", "ക്രിപ്റ്റോ മാർക്കറ്റ് ലൈവ് വിവരങ്ങൾ.", "Bitcoin, Ethereum, Solana എന്നിവയുടെ തത്സമയ മാർക്കറ്റ് വിലകളും രൂപയിലെ (INR) മൂല്യവും നൽകുന്നു."),
        ("Media Document Converter", "FFmpeg മീഡിയ കൺവേർട്ടർ.", "വീഡിയോ കൺവേർഷൻ, കംപ്രഷൻ, 320kbps MP3 ഓഡിയോ എക്സ്ട്രാക്ഷൻ, PDF നിർമ്മാണം എന്നിവ നടത്തുന്നു."),
        ("Network Speed & IP Info", "നെറ്റ്‌വർക്ക് സ്പീഡ് & IP വിവരങ്ങൾ.", "ഡൗൺലോഡ്/അപ്‌ലോഡ് സ്പീഡ്, പിംഗ്, പബ്ലിക് IP ലൊക്കേഷൻ എന്നിവ കൃത്യമായി പരിശോധിക്കുന്നു."),
        ("Password & Token Generator", "സ്ട്രോങ്ങ് പാസ്‌വേഡ് നിർമ്മാതാവ്.", "ഹാക്ക് ചെയ്യാൻ സാധിക്കാത്ത ശക്തമായ റാൻഡം പാസ്‌വേഡുകളും API ടോക്കണുകളും നിർമ്മിക്കുന്നു."),
        ("QR Code Terminal Engine", "ടെർമിനൽ QR ജനറേറ്റർ.", "ടെർമിനൽ സ്ക്രീനിൽ തന്നെ ASCII QR കോഡുകൾ കാണിക്കുകയും PNG ഇമേജുകളായി സേവ് ചെയ്യുകയും ചെയ്യുന്നു."),
        ("Seeker OSINT Explorer", "ലൊക്കേഷൻ ട്രാക്കിംഗ് ഫ്രെയിംവർക്ക്.", "കൃത്യമായ അക്ഷാംശം, രേഖാംശം എന്നിവ കണ്ടെത്തുന്ന അത്യാധുനിക OSINT ലൊക്കേഷൻ ടൂൾ."),
        ("Spotify Smart Downloader", "സ്പോട്ടിഫൈ മ്യൂസിക് ഡൗൺലോഡർ.", "സ്പോട്ടിഫൈ ഗാനങ്ങൾ, ആൽബങ്ങൾ, വീഡിയോകൾ എന്നിവ 320kbps അൾട്രാ ക്വാളിറ്റിയിൽ ഡൗൺലോഡ് ചെയ്യുന്നു."),
        ("System Auto-Repair Engine", "സിസ്റ്റം ഓട്ടോ-റിപ്പയർ എഞ്ചിൻ.", "കേടായ ഫോൾഡറുകൾ, പെർമിഷനുകൾ, പൈത്തൺ ലൈബ്രറികൾ എന്നിവ തനിയെ പരിശോധിച്ച് പരിഹരിക്കുന്നു."),
        ("System Hardware Benchmark", "ഹാർഡ്‌വെയർ സ്പീഡ് ടെസ്റ്റർ.", "ഫോണിന്റെ/ലാപ്ടോപ്പിന്റെ CPU പ്രകടനക്ഷമതയും സ്പീഡ് സ്കോറും അളക്കുന്നു."),
        ("Telegram Cloud Hub", "ടെലിഗ്രാം ക്ലൗഡ് ഫയൽ സിങ്ക്.", "ലൈവ് സ്പീഡിൽ (MB/s) ടെലിഗ്രാം ഫയലുകൾ അപ്‌ലോഡ്/ഡൗൺലോഡ് ചെയ്യാനും മൾട്ടി-അക്കൗണ്ട് മാനേജ് ചെയ്യാനും സഹായിക്കുന്നു."),
        ("Temporary Email & Inbox", "താല്കാലിക ഇമെയിൽ & ഇൻബോക്സ്.", "OTP-കളും വെരിഫിക്കേഷൻ സന്ദേശങ്ങളും സ്വീകരിക്കാൻ തത്സമയ ഡിസ്പോസബിൾ ഇമെയിൽ നൽകുന്നു."),
        ("TeraBox Fast Downloader", "ടെറാബോക്സ് വീഡിയോ ഡൗൺലോഡർ.", "വേഗത നിയന്ത്രണങ്ങൾ ഇല്ലാതെ ടെറാബോക്സ് വീഡിയോകൾ പരമാവധി സ്പീഡിൽ ഡൗൺലോഡ് ചെയ്യുന്നു."),
        ("Storage & App Cache Purger", "കാഷെ & ജങ്ക് ക്ലീനർ.", "പൈത്തൺ ബൈറ്റ്കോഡ്, ആപ്പ് ലോഗുകൾ, സിസ്റ്റം കാഷെ എന്നിവ നീക്കം ചെയ്ത് മെമ്മറി വർദ്ധിപ്പിക്കുന്നു."),
        ("Universal Media Downloader", "മൾട്ടി-പ്ലാറ്റ്‌ഫോം ഡൗൺലോഡർ.", "YouTube, Instagram, Facebook, X വീഡിയോകൾ തത്സമയ സ്പീഡ് മീറ്ററോടെ ഡൗൺലോഡ് ചെയ്യുന്നു."),
        ("Web Headers & Recon Fetcher", "വെബ് സെർവർ ഇൻസ്പെക്ടർ.", "ഏതൊരു വെബ്‌സൈറ്റിന്റെയും സെർവർ ഹെഡറുകളും സുരക്ഷാ ഫ്ലാഗുകളും പരിശോധിക്കുന്നു.")
    ]
}

def display_doc(data):
    while True:
        clear_screen()
        print(f"{C_YELLOW}─── [ 🌟 {data['title']} ] ───{C_RESET}")
        print(f"{C_WHITE}{data['overview']}{C_RESET}\n")
        print(f"{C_CYAN}╔══════════════════ [ AVAILABLE MODULES LIST ] ══════════════════╗{C_RESET}")
        for idx, (name, subtitle, _) in enumerate(data['tools']):
            print(f"  {C_CYAN}[{idx+1:02d}]{C_RESET} {C_GREEN}{name:<28}{C_RESET} - {C_WHITE}{subtitle[:38]}{C_RESET}")
        print(f"{C_CYAN}╚════════════════════════════════════════════════════════════════╝{C_RESET}")
        print(f"  {C_YELLOW}[A]{C_RESET} Read All Detailed Modules Sequentially")
        print(f"  {C_CYAN}[#]{C_RESET} Back to Language Selector")
        print(f"  {C_RED}[*]{C_RESET} Full Exit to Terminal")
        print(f"{C_CYAN}─"*60 + f"{C_RESET}")

        c = input(f"{C_GREEN}➤ Select Module (1-{len(data['tools'])}) or Action: {C_RESET}").strip().lower()
        if c in ['#', 'b', 'back']: break
        elif c in ['*', 'x', 'exit', 'q']: sys.exit(0)
        elif c == 'a':
            for name, subtitle, details in data['tools']:
                clear_screen()
                print(f"{C_CYAN}╔════════════════════════════════════════════════════════════════╗{C_RESET}")
                print(f"  {C_YELLOW}MODULE NAME :{C_RESET} {C_GREEN}{name}{C_RESET}")
                print(f"  {C_YELLOW}PURPOSE     :{C_RESET} {C_WHITE}{subtitle}{C_RESET}")
                print(f"{C_CYAN}────────────────────────────────────────────────────────────────{C_RESET}")
                print(f"{C_WHITE}{details}{C_RESET}")
                print(f"{C_CYAN}╚════════════════════════════════════════════════════════════════╝{C_RESET}")
                input(f"\n{C_YELLOW}Press Enter for next module...{C_RESET}")
        elif c.isdigit() and 1 <= int(c) <= len(data['tools']):
            name, subtitle, details = data['tools'][int(c)-1]
            clear_screen()
            print(f"{C_CYAN}╔════════════════════════════════════════════════════════════════╗{C_RESET}")
            print(f"  {C_YELLOW}MODULE NAME :{C_RESET} {C_GREEN}{name}{C_RESET}")
            print(f"  {C_YELLOW}PURPOSE     :{C_RESET} {C_WHITE}{subtitle}{C_RESET}")
            print(f"{C_CYAN}────────────────────────────────────────────────────────────────{C_RESET}")
            print(f"{C_WHITE}{details}{C_RESET}")
            print(f"{C_CYAN}╚════════════════════════════════════════════════════════════════╝{C_RESET}")
            input(f"\n{C_YELLOW}Press Enter to return to module list...{C_RESET}")

def main():
    while True:
        clear_screen()
        print(f"  {C_YELLOW}─── [ 🌐 SELECT DETAILED MANUAL LANGUAGE ] ───{C_RESET}")
        print(f"  {C_CYAN}[1]{C_RESET} English (Comprehensive 23-Module Technical Manual)")
        print(f"  {C_CYAN}[2]{C_RESET} മലയാളം (23 മൊഡ്യൂളുകളുടെയും സമഗ്ര വിവരണം)")
        print(f"{C_CYAN}─"*60 + f"{C_RESET}")
        print(f"  {C_CYAN}[#]{C_RESET} Back to Main Hub Dashboard")
        print(f"  {C_RED}[*]{C_RESET} Full Exit to Terminal")
        print(f"{C_CYAN}═"*60 + f"{C_RESET}")

        c = input(f"{C_GREEN}➤ Select Language (1-2): {C_RESET}").strip().lower()
        if c == '1': display_doc(DATA_EN)
        elif c == '2': display_doc(DATA_ML)
        elif c in ['#', 'b', 'back']: break
        elif c in ['*', 'x', 'exit', 'q']: sys.exit(0)

if __name__ == "__main__": main()
