import os, sys, subprocess, shutil, glob

C_CYAN = "\033[1;36m"
C_GREEN = "\033[1;32m"
C_YELLOW = "\033[1;33m"
C_RED = "\033[1;31m"
C_MAGENTA = "\033[1;35m"
C_WHITE = "\033[1;37m"
C_RESET = "\033[0m"

BANNER = """[1;36m┌────────────────────────────────────────────────────────────┐
[1;37m  ████████╗██████╗  █████╗  ██████╗███████╗
  ╚══██╔══╝██╔══██╗██╔══██╗██╔════╝██╔════╝
     ██║   ██████╔╝███████║██║     █████╗  
     ██║   ██╔══██╗██╔══██║██║     ██╔══╝  
     ██║   ██║  ██║██║  ██║╚██████╗███████╗
     ╚═╝   ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚══════╝

  ███████╗██████╗ ██╗   ██╗██████╗ ███████╗██████╗ 
  ██╔════╝██╔══██╗╚██╗ ██╔╝██╔══██╗██╔════╝██╔══██╗
  ███████╗██████╔╝ ╚████╔╝ ██║  ██║█████╗  ██████╔╝
  ╚════██║██╔═══╝   ╚██╔╝  ██║  ██║██╔══╝  ██╔══██╗
  ███████║██║        ██║   ██████╔╝███████╗██║  ██║
  ╚══════╝╚═╝        ╚═╝   ╚═════╝ ╚══════╝╚═╝  ╚═╝
[0m
         [1;33m🕷️  [1;36mG O W R I   S H A N K A R[1;33m  🕷️[0m
           [1;35m⚡ ═ [1;32mT E R M I N A L   H U B[1;35m ═ ⚡[0m
[1;36m└────────────────────────────────────────────────────────────┘[0m"""

def get_download_dir():
    if os.name == 'nt':
        return os.path.join(os.path.expanduser("~"), "Downloads")
    if os.path.exists("/sdcard/Download"):
        return "/sdcard/Download"
    return os.path.expanduser("~/Downloads")

def get_music_dir():
    if os.name == 'nt':
        return os.path.join(os.path.expanduser("~"), "Music")
    if os.path.exists("/sdcard/Music"):
        return "/sdcard/Music"
    return os.path.expanduser("~/Music")

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')
    print(BANNER)
    print(f"{C_MAGENTA}  [▸] ACTIVE MODULE : {C_GREEN}FAST MEDIA & DOC CONVERTER{C_RESET}")
    print(f"{C_CYAN}─"*60 + f"{C_RESET}")

from PIL import Image

def get_input_path(prompt_text):
    path = input(f"{C_GREEN}➤ {prompt_text} ([#] Back / [*] Exit): {C_RESET}").strip().strip("'\"")
    if path.lower() in ['#', 'b', 'back']: return None
    elif path.lower() in ['*', 'x', 'exit', 'q']: sys.exit(0)
    if not os.path.exists(path):
        print(f"\n{C_RED}❌ Error: File not found!{C_RESET}")
        input("Press Enter...")
        return False
    return path

def main():
    while True:
        clear_screen()
        print(f"  {C_CYAN}[1]{C_RESET} Audio Format Conversion (WAV/AAC/OGG to MP3)")
        print(f"  {C_CYAN}[2]{C_RESET} Compress Video (Reduce File Size)")
        print(f"  {C_CYAN}[3]{C_RESET} Image Format Switcher (JPG ⇆ PNG ⇆ WEBP)")
        print(f"  {C_CYAN}[4]{C_RESET} Images (JPG/PNG) to PDF Document")
        print(f"  {C_CYAN}[5]{C_RESET} PDF Document to Images (PNG/JPG Pages)")
        print(f"  {C_CYAN}[6]{C_RESET} Video Format Conversion (MKV/AVI/WEBM to MP4)")
        print(f"  {C_CYAN}[7]{C_RESET} Video to Animated GIF")
        print(f"  {C_CYAN}[8]{C_RESET} Video to MP3 Audio (320kbps Crystal Clear)")
        print(f"{C_CYAN}─"*60 + f"{C_RESET}")
        print(f"  {C_CYAN}[#]{C_RESET} Back to Main Menu Hub")
        print(f"  {C_RED}[*]{C_RESET} Full Exit to Terminal")
        print(f"{C_CYAN}═"*60 + f"{C_RESET}")

        c = input(f"{C_GREEN}➤ Select Option (1-8): {C_RESET}").strip().lower()
        if c in ['#', 'b', 'back']: break
        elif c in ['*', 'x', 'exit', 'q']: sys.exit(0)
        elif c in ['1', '2', '6', '7', '8']:
            p = get_input_path("Enter Media File Path")
            if not p: continue
            base = os.path.splitext(p)[0]
            cmd = []
            if c == '1': cmd = ["ffmpeg", "-i", p, "-ab", "320k", base + "_converted.mp3", "-y"]
            elif c == '2': cmd = ["ffmpeg", "-i", p, "-vcodec", "libx264", "-crf", "28", base + "_compressed.mp4", "-y"]
            elif c == '6': cmd = ["ffmpeg", "-i", p, "-c:v", "libx264", "-c:a", "aac", base + "_converted.mp4", "-y"]
            elif c == '7': cmd = ["ffmpeg", "-i", p, "-vf", "fps=10,scale=320:-1:flags=lanczos", base + ".gif", "-y"]
            elif c == '8': cmd = ["ffmpeg", "-i", p, "-vn", "-ab", "320k", base + ".mp3", "-y"]
            subprocess.run(cmd)
            input(f"\n{C_GREEN}✅ Processed! Press Enter...{C_RESET}")
        elif c == '3':
            p = get_input_path("Enter Image File Path")
            if not p: continue
            fmt = input("Target format (png/jpg/webp): ").strip().lower()
            if fmt in ['png', 'jpg', 'jpeg', 'webp']:
                im = Image.open(p)
                if fmt in ['jpg', 'jpeg']: im = im.convert('RGB')
                im.save(os.path.splitext(p)[0] + f"_converted.{fmt}")
                input(f"\n{C_GREEN}✅ Saved! Press Enter...{C_RESET}")
        elif c == '4':
            p = get_input_path("Enter Image File or Folder")
            if not p: continue
            out_pdf = os.path.splitext(p)[0] + "_converted.pdf"
            if os.path.isfile(p):
                Image.open(p).convert('RGB').save(out_pdf)
            else:
                imgs = [os.path.join(p, f) for f in os.listdir(p) if f.lower().endswith(('.jpg', '.jpeg', '.png'))]
                imgs.sort()
                p_imgs = [Image.open(f).convert('RGB') for f in imgs]
                if p_imgs: p_imgs[0].save(out_pdf, save_all=True, append_images=p_imgs[1:])
            input(f"\n{C_GREEN}✅ PDF Created! Press Enter...{C_RESET}")
        elif c == '5':
            p = get_input_path("Enter PDF File Path")
            if not p: continue
            out_dir = os.path.splitext(p)[0] + "_images"
            os.makedirs(out_dir, exist_ok=True)
            subprocess.run(["pdftoppm", "-png", p, os.path.join(out_dir, "page")])
            input(f"\n{C_GREEN}✅ Images Extracted to {out_dir}! Press Enter...{C_RESET}")

if __name__ == "__main__": main()
