import os, sys, subprocess, shutil, glob, time

C_CYAN = "\033[1;36m"
C_GREEN = "\033[1;32m"
C_YELLOW = "\033[1;33m"
C_RED = "\033[1;31m"
C_MAGENTA = "\033[1;35m"
C_WHITE = "\033[1;37m"
C_RESET = "\033[0m"

BANNER = """[1;36m┌────────────────────────────────────────────────────────────┐
[1;37m  ████████╗██████╗  █████╗  ██████╗███████╗
  ╚══██╔══╝██╔══██╗██╔══██╗██╔════╝██╔════╝
     ██║   ██████╔╝███████║██║     █████╗  
     ██║   ██╔══██╗██╔══██║██║     ██╔══╝  
     ██║   ██║  ██║██║  ██║╚██████╗███████╗
     ╚═╝   ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚══════╝

  ███████╗██████╗ ██╗   ██╗██████╗ ███████╗██████╗ 
  ██╔════╝██╔══██╗╚██╗ ██╔╝██╔══██╗██╔════╝██╔══██╗
  ███████╗██████╔╝ ╚████╔╝ ██║  ██║█████╗  ██████╔╝
  ╚════██║██╔═══╝   ╚██╔╝  ██║  ██║██╔══╝  ██╔══██╗
  ███████║██║        ██║   ██████╔╝███████╗██║  ██║
  ╚══════╝╚═╝        ╚═╝   ╚═════╝ ╚══════╝╚═╝  ╚═╝
[0m
         [1;33m🕷️  [1;36mG O W R I   S H A N K A R[1;33m  🕷️[0m
           [1;35m⚡ ═ [1;32mT E R M I N A L   H U B[1;35m ═ ⚡[0m
[1;36m└────────────────────────────────────────────────────────────┘[0m"""

def get_download_dir():
    if os.name == 'nt':
        return os.path.join(os.path.expanduser("~"), "Downloads")
    if os.path.exists("/sdcard/Download"):
        return "/sdcard/Download"
    return os.path.expanduser("~/Downloads")

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')
    print(BANNER)
    print(f"{C_MAGENTA}  [▸] ACTIVE MODULE : {C_GREEN}LINK EXPANDER & SAFETY CHECKER{C_RESET}")
    print(f"{C_CYAN}─"*60 + f"{C_RESET}")

import requests

def unshorten():
    clear_screen()
    url = input(f"{C_GREEN}➤ Enter Short URL (bit.ly, tinyurl, etc): {C_RESET}").strip()
    if not url: return
    if not url.startswith("http"): url = "https://" + url

    print(f"
{C_YELLOW}[*] Tracing URL redirects safely...{C_RESET}")
    try:
        r = requests.head(url, allow_redirects=True, timeout=10)
        print(f"
{C_CYAN}╔════════════════════════════════════════════════════════════╗{C_RESET}")
        print(f"  {C_GREEN}🔗 Original Destination URL:{C_RESET}")
        print(f"  {C_WHITE}{r.url}{C_RESET}")
        print(f"  {C_CYAN}Status Code:{C_RESET} {r.status_code}")
        print(f"{C_CYAN}╚════════════════════════════════════════════════════════════╝{C_RESET}")
    except Exception as e:
        print(f"{C_RED}❌ Trace failed: {e}{C_RESET}")
    input("
Press Enter to continue...")

def main():
    while True:
        clear_screen()
        print(f"  {C_CYAN}[1]{C_RESET} Unshorten & Inspect Link")
        print(f"{C_CYAN}─"*60 + f"{C_RESET}")
        print(f"  {C_CYAN}[#]{C_RESET} Back to Main Menu")
        print(f"  {C_RED}[*]{C_RESET} Full Exit to Terminal")
        print(f"{C_CYAN}═"*60 + f"{C_RESET}")
        c = input(f"{C_GREEN}➤ Option (1): {C_RESET}").strip().lower()
        if c == '1': unshorten()
        elif c in ['#', 'b', 'back']: break
        elif c in ['*', 'x', 'exit', 'q']: sys.exit(0)

if __name__ == "__main__": main()
