import os, sys, subprocess, shutil, glob, time

C_CYAN = "\033[1;36m"
C_GREEN = "\033[1;32m"
C_YELLOW = "\033[1;33m"
C_RED = "\033[1;31m"
C_MAGENTA = "\033[1;35m"
C_WHITE = "\033[1;37m"
C_RESET = "\033[0m"

BANNER = """[1;36m┌────────────────────────────────────────────────────────────┐
[1;37m  ████████╗██████╗  █████╗  ██████╗███████╗
  ╚══██╔══╝██╔══██╗██╔══██╗██╔════╝██╔════╝
     ██║   ██████╔╝███████║██║     █████╗  
     ██║   ██╔══██╗██╔══██║██║     ██╔══╝  
     ██║   ██║  ██║██║  ██║╚██████╗███████╗
     ╚═╝   ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚══════╝

  ███████╗██████╗ ██╗   ██╗██████╗ ███████╗██████╗ 
  ██╔════╝██╔══██╗╚██╗ ██╔╝██╔══██╗██╔════╝██╔══██╗
  ███████╗██████╔╝ ╚████╔╝ ██║  ██║█████╗  ██████╔╝
  ╚════██║██╔═══╝   ╚██╔╝  ██║  ██║██╔══╝  ██╔══██╗
  ███████║██║        ██║   ██████╔╝███████╗██║  ██║
  ╚══════╝╚═╝        ╚═╝   ╚═════╝ ╚══════╝╚═╝  ╚═╝
[0m
         [1;33m🕷️  [1;36mG O W R I   S H A N K A R[1;33m  🕷️[0m
           [1;35m⚡ ═ [1;32mT E R M I N A L   H U B[1;35m ═ ⚡[0m
[1;36m└────────────────────────────────────────────────────────────┘[0m"""

def get_download_dir():
    if os.name == 'nt':
        return os.path.join(os.path.expanduser("~"), "Downloads")
    if os.path.exists("/sdcard/Download"):
        return "/sdcard/Download"
    return os.path.expanduser("~/Downloads")

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')
    print(BANNER)
    print(f"{C_MAGENTA}  [▸] ACTIVE MODULE : {C_GREEN}TERMINAL QR CODE ENGINE{C_RESET}")
    print(f"{C_CYAN}─"*60 + f"{C_RESET}")

import qrcode

def generate_qr():
    clear_screen()
    data = input(f"{C_GREEN}➤ Enter Text or URL to generate QR: {C_RESET}").strip()
    if not data: return
    
    qr = qrcode.QRCode()
    qr.add_data(data)
    qr.make()
    
    print(f"
{C_YELLOW}[*] Displaying Terminal QR Code:{C_RESET}
")
    qr.print_ascii(invert=True)
    
    save_opt = input(f"
{C_GREEN}➤ Save as PNG Image in Downloads? (y/n): {C_RESET}").strip().lower()
    if save_opt == 'y':
        out_path = os.path.join(get_download_dir(), "qr_generated.png")
        img = qr.make_image(fill_color="black", back_color="white")
        img.save(out_path)
        print(f"{C_GREEN}✅ Saved: {out_path}{C_RESET}")
    input("
Press Enter to continue...")

def main():
    while True:
        clear_screen()
        print(f"  {C_CYAN}[1]{C_RESET} Generate & View Terminal ASCII QR Code")
        print(f"{C_CYAN}─"*60 + f"{C_RESET}")
        print(f"  {C_CYAN}[#]{C_RESET} Back to Main Menu")
        print(f"  {C_RED}[*]{C_RESET} Full Exit to Terminal")
        print(f"{C_CYAN}═"*60 + f"{C_RESET}")
        c = input(f"{C_GREEN}➤ Option (1): {C_RESET}").strip().lower()
        if c == '1': generate_qr()
        elif c in ['#', 'b', 'back']: break
        elif c in ['*', 'x', 'exit', 'q']: sys.exit(0)

if __name__ == "__main__": main()
