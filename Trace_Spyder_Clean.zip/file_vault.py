import os, sys, subprocess, shutil, glob, time

C_CYAN = "\033[1;36m"
C_GREEN = "\033[1;32m"
C_YELLOW = "\033[1;33m"
C_RED = "\033[1;31m"
C_MAGENTA = "\033[1;35m"
C_WHITE = "\033[1;37m"
C_RESET = "\033[0m"

BANNER = """[1;36m┌────────────────────────────────────────────────────────────┐
[1;37m  ████████╗██████╗  █████╗  ██████╗███████╗
  ╚══██╔══╝██╔══██╗██╔══██╗██╔════╝██╔════╝
     ██║   ██████╔╝███████║██║     █████╗  
     ██║   ██╔══██╗██╔══██║██║     ██╔══╝  
     ██║   ██║  ██║██║  ██║╚██████╗███████╗
     ╚═╝   ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚══════╝

  ███████╗██████╗ ██╗   ██╗██████╗ ███████╗██████╗ 
  ██╔════╝██╔══██╗╚██╗ ██╔╝██╔══██╗██╔════╝██╔══██╗
  ███████╗██████╔╝ ╚████╔╝ ██║  ██║█████╗  ██████╔╝
  ╚════██║██╔═══╝   ╚██╔╝  ██║  ██║██╔══╝  ██╔══██╗
  ███████║██║        ██║   ██████╔╝███████╗██║  ██║
  ╚══════╝╚═╝        ╚═╝   ╚═════╝ ╚══════╝╚═╝  ╚═╝
[0m
         [1;33m🕷️  [1;36mG O W R I   S H A N K A R[1;33m  🕷️[0m
           [1;35m⚡ ═ [1;32mT E R M I N A L   H U B[1;35m ═ ⚡[0m
[1;36m└────────────────────────────────────────────────────────────┘[0m"""

def get_download_dir():
    if os.name == 'nt':
        return os.path.join(os.path.expanduser("~"), "Downloads")
    if os.path.exists("/sdcard/Download"):
        return "/sdcard/Download"
    return os.path.expanduser("~/Downloads")

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')
    print(BANNER)
    print(f"{C_MAGENTA}  [▸] ACTIVE MODULE : {C_GREEN}AES-256 FILE SECURITY VAULT{C_RESET}")
    print(f"{C_CYAN}─"*60 + f"{C_RESET}")

import base64, hashlib
from cryptography.fernet import Fernet

def get_key_from_password(password: str) -> bytes:
    key = hashlib.sha256(password.encode()).digest()
    return base64.urlsafe_b64encode(key)

def encrypt_file():
    clear_screen()
    fp = input(f"{C_GREEN}➤ Enter File Path to Encrypt: {C_RESET}").strip().strip("'\"")
    if not os.path.exists(fp):
        input(f"{C_RED}❌ File not found! Press Enter...{C_RESET}")
        return
    pwd = input(f"{C_GREEN}➤ Enter Secure Password: {C_RESET}").strip()
    if not pwd: return

    f = Fernet(get_key_from_password(pwd))
    with open(fp, 'rb') as file:
        data = file.read()
    encrypted = f.encrypt(data)
    out_file = fp + ".locked"
    with open(out_file, 'wb') as file:
        file.write(encrypted)
    
    os.remove(fp)
    print(f"
{C_GREEN}🔒 File Encrypted & Original Deleted: {out_file}{C_RESET}")
    input("Press Enter to continue...")

def decrypt_file():
    clear_screen()
    fp = input(f"{C_GREEN}➤ Enter .locked File Path to Decrypt: {C_RESET}").strip().strip("'\"")
    if not os.path.exists(fp):
        input(f"{C_RED}❌ File not found! Press Enter...{C_RESET}")
        return
    pwd = input(f"{C_GREEN}➤ Enter Password: {C_RESET}").strip()
    if not pwd: return

    try:
        f = Fernet(get_key_from_password(pwd))
        with open(fp, 'rb') as file:
            data = file.read()
        decrypted = f.decrypt(data)
        out_file = fp.replace(".locked", "")
        with open(out_file, 'wb') as file:
            file.write(decrypted)
        os.remove(fp)
        print(f"
{C_GREEN}🔓 File Decrypted Successfully: {out_file}{C_RESET}")
    except Exception:
        print(f"
{C_RED}❌ Decryption failed! Wrong password or corrupted file.{C_RESET}")
    input("
Press Enter to continue...")

def main():
    while True:
        clear_screen()
        print(f"  {C_CYAN}[1]{C_RESET} Lock & Encrypt File (AES-256)")
        print(f"  {C_CYAN}[2]{C_RESET} Unlock & Decrypt File (.locked)")
        print(f"{C_CYAN}─"*60 + f"{C_RESET}")
        print(f"  {C_CYAN}[#]{C_RESET} Back to Main Menu")
        print(f"  {C_RED}[*]{C_RESET} Full Exit to Terminal")
        print(f"{C_CYAN}═"*60 + f"{C_RESET}")
        c = input(f"{C_GREEN}➤ Option (1-2): {C_RESET}").strip().lower()
        if c == '1': encrypt_file()
        elif c == '2': decrypt_file()
        elif c in ['#', 'b', 'back']: break
        elif c in ['*', 'x', 'exit', 'q']: sys.exit(0)

if __name__ == "__main__": main()
