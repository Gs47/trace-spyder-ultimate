import os, sys, shutil, subprocess, glob

C_CYAN = "\033[1;36m"
C_GREEN = "\033[1;32m"
C_YELLOW = "\033[1;33m"
C_RED = "\033[1;31m"
C_MAGENTA = "\033[1;35m"
C_WHITE = "\033[1;37m"
C_RESET = "\033[0m"

BANNER = f"""{C_CYAN}┌────────────────────────────────────────────────────────────┐
{C_WHITE}  ████████╗██████╗  █████╗  ██████╗███████╗
  ╚══██╔══╝██╔══██╗██╔══██╗██╔════╝██╔════╝
     ██║   ██████╔╝███████║██║     █████╗  
     ██║   ██╔══██╗██╔══██║██║     ██╔══╝  
     ██║   ██║  ██║██║  ██║╚██████╗███████╗
     ╚═╝   ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚══════╝

  ███████╗██████╗ ██╗   ██╗██████╗ ███████╗██████╗ 
  ██╔════╝██╔══██╗╚██╗ ██╔╝██╔══██╗██╔════╝██╔══██╗
  ███████╗██████╔╝ ╚████╔╝ ██║  ██║█████╗  ██████╔╝
  ╚════██║██╔═══╝   ╚██╔╝  ██║  ██║██╔══╝  ██╔══██╗
  ███████║██║        ██║   ██████╔╝███████╗██║  ██║
  ╚══════╝╚═╝        ╚═╝   ╚═════╝ ╚══════╝╚═╝  ╚═╝
{C_RESET}
         {C_YELLOW}🕷️  {C_CYAN}G O W R I   S H A N K A R{C_YELLOW}  🕷️{C_RESET}
           {C_MAGENTA}⚡ ═ {C_GREEN}T E R M I N A L   H U B{C_MAGENTA} ═ ⚡{C_RESET}
{C_CYAN}└────────────────────────────────────────────────────────────┘{C_RESET}"""

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')
    print(BANNER)
    print(f"{C_MAGENTA}  [▸] ACTIVE MODULE : {C_GREEN}STORAGE & APP CACHE PURGER{C_RESET}")
    print(f"{C_CYAN}─"*60 + f"{C_RESET}")

def get_free_space():
    try:
        path = "C:\\" if os.name == 'nt' else ('/sdcard' if os.path.exists('/sdcard') else os.path.expanduser("~"))
        _, _, free_b = shutil.disk_usage(path)
        return free_b
    except Exception: return 0

def format_size(bytes_val):
    mb = bytes_val / (1024 * 1024)
    if mb >= 1024: return f"{mb / 1024:.2f} GB"
    return f"{mb:.2f} MB"

def clean_app_internal_cache():
    clear_screen()
    print(f"{C_YELLOW}[*] Purging Trace Spyder App Cache & Logs...{C_RESET}\n")
    cleared_count = 0
    
    # 1. Clean Python __pycache__ and .pyc files
    for root, dirs, files in os.walk(os.path.expanduser("~")):
        for d in dirs:
            if d == "__pycache__":
                shutil.rmtree(os.path.join(root, d), ignore_errors=True)
                cleared_count += 1
        for f in files:
            if f.endswith(".pyc") or f.endswith(".pyo"):
                try:
                    os.remove(os.path.join(root, f))
                    cleared_count += 1
                except Exception: pass

    # 2. Clean App Temp Files
    temp_files = [
        os.path.expanduser("~/.temp_active_mail.txt"),
        os.path.expanduser("~/.tg_active_session_name.txt")
    ]
    for tf in temp_files:
        if os.path.exists(tf):
            try:
                os.remove(tf)
                cleared_count += 1
            except Exception: pass

    print(f"{C_GREEN}[✓] Cleaned {cleared_count} app cache & temporary files!{C_RESET}")
    print(f"{C_CYAN}─"*60 + f"{C_RESET}")
    input("Press Enter to continue...")

def clean_system_junk():
    clear_screen()
    print(f"{C_YELLOW}[*] Purging System Cache, Temp & Pip Buffers...{C_RESET}\n")
    initial_free = get_free_space()
    
    paths = [
        "/data/data/com.termux/files/usr/tmp",
        os.path.expanduser("~/.cache"),
        os.path.expanduser("~/.npm"),
        os.path.expanduser("~/.pip")
    ]
    for p in paths:
        if os.path.exists(p):
            try:
                if os.path.isdir(p): shutil.rmtree(p, ignore_errors=True)
                else: os.remove(p)
                print(f"  {C_GREEN}[✓] Cleared:{C_RESET} {p}")
            except Exception: pass
            
    os.makedirs("/data/data/com.termux/files/usr/tmp", exist_ok=True)
    subprocess.run(["apt-get", "clean"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    subprocess.run(["pip", "cache", "purge"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    
    final_free = get_free_space()
    print(f"\n{C_CYAN}─"*60 + f"{C_RESET}")
    print(f"[*] Initial Free Space : {format_size(initial_free)}")
    print(f"[*] Current Free Space : {format_size(final_free)}")
    print(f"{C_GREEN}🔥 TOTAL SPACE RECLAIMED : {format_size(max(0, final_free - initial_free))}{C_RESET}")
    print(f"{C_CYAN}─"*60 + f"{C_RESET}")
    input("\nPress Enter to continue...")

def clean_all_cache():
    clean_app_internal_cache()
    clean_system_junk()

def main():
    while True:
        clear_screen()
        print(f"  {C_CYAN}[1]{C_RESET} Clean Trace Spyder App Internal Cache (Python/Temp/Logs)")
        print(f"  {C_CYAN}[2]{C_RESET} Clean System Temp & Package Cache (Pip/Apt/Tmp)")
        print(f"  {C_CYAN}[3]{C_RESET} Deep Purge All Cache & Junk Files (Full Clean)")
        print(f"{C_CYAN}─"*60 + f"{C_RESET}")
        print(f"  {C_CYAN}[#]{C_RESET} Back to Main Menu Hub")
        print(f"  {C_RED}[*]{C_RESET} Full Exit to Terminal")
        print(f"{C_CYAN}═"*60 + f"{C_RESET}")

        c = input(f"{C_GREEN}➤ Select Cleaning Option (1-3): {C_RESET}").strip().lower()
        if c == '1': clean_app_internal_cache()
        elif c == '2': clean_system_junk()
        elif c == '3': clean_all_cache()
        elif c in ['#', 'b', 'back']: break
        elif c in ['*', 'x', 'exit', 'q']: sys.exit(0)

if __name__ == "__main__":
    main()
