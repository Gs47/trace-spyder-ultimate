import os, sys, subprocess, shutil, glob, time

C_CYAN = "\033[1;36m"
C_GREEN = "\033[1;32m"
C_YELLOW = "\033[1;33m"
C_RED = "\033[1;31m"
C_MAGENTA = "\033[1;35m"
C_WHITE = "\033[1;37m"
C_RESET = "\033[0m"

BANNER = """[1;36m┌────────────────────────────────────────────────────────────┐
[1;37m  ████████╗██████╗  █████╗  ██████╗███████╗
  ╚══██╔══╝██╔══██╗██╔══██╗██╔════╝██╔════╝
     ██║   ██████╔╝███████║██║     █████╗  
     ██║   ██╔══██╗██╔══██║██║     ██╔══╝  
     ██║   ██║  ██║██║  ██║╚██████╗███████╗
     ╚═╝   ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚══════╝

  ███████╗██████╗ ██╗   ██╗██████╗ ███████╗██████╗ 
  ██╔════╝██╔══██╗╚██╗ ██╔╝██╔══██╗██╔════╝██╔══██╗
  ███████╗██████╔╝ ╚████╔╝ ██║  ██║█████╗  ██████╔╝
  ╚════██║██╔═══╝   ╚██╔╝  ██║  ██║██╔══╝  ██╔══██╗
  ███████║██║        ██║   ██████╔╝███████╗██║  ██║
  ╚══════╝╚═╝        ╚═╝   ╚═════╝ ╚══════╝╚═╝  ╚═╝
[0m
         [1;33m🕷️  [1;36mG O W R I   S H A N K A R[1;33m  🕷️[0m
           [1;35m⚡ ═ [1;32mT E R M I N A L   H U B[1;35m ═ ⚡[0m
[1;36m└────────────────────────────────────────────────────────────┘[0m"""

def get_download_dir():
    if os.name == 'nt':
        return os.path.join(os.path.expanduser("~"), "Downloads")
    if os.path.exists("/sdcard/Download"):
        return "/sdcard/Download"
    return os.path.expanduser("~/Downloads")

def get_music_dir():
    if os.name == 'nt':
        return os.path.join(os.path.expanduser("~"), "Music")
    if os.path.exists("/sdcard/Music"):
        return "/sdcard/Music"
    return os.path.expanduser("~/Music")

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')
    print(BANNER)
    print(f"{C_MAGENTA}  [▸] ACTIVE MODULE : {C_GREEN}UNIVERSAL MEDIA DOWNLOADER{C_RESET}")
    print(f"{C_CYAN}─"*60 + f"{C_RESET}")

def run_yt_dlp(url, out_dir):
    print(f"\n{C_YELLOW}[*] Initializing High-Speed Stream Engine...{C_RESET}")
    cmd = [
        "yt-dlp",
        "--progress",
        "--newline",
        "--progress-template",
        "download:[[1;32m%(progress._percent_str)s[0m] Size: [1;36m%(progress._total_bytes_str,progress._total_bytes_estimate_str)s[0m | Speed: [1;33m%(progress._speed_str)s[0m | ETA: [1;35m%(progress._eta_str)s[0m",
        "-P", out_dir,
        url
    ]
    subprocess.run(cmd)

def main():
    while True:
        clear_screen()
        print(f"  {C_CYAN}[1]{C_RESET} Facebook Video Downloader")
        print(f"  {C_CYAN}[2]{C_RESET} Instagram Reels / Post / Story")
        print(f"  {C_CYAN}[3]{C_RESET} TeraBox Fast Video Downloader")
        print(f"  {C_CYAN}[4]{C_RESET} Universal Stream Downloader (TikTok / X / Others)")
        print(f"  {C_CYAN}[5]{C_RESET} YouTube Video / Shorts / Playlist")
        print(f"{C_CYAN}─"*60 + f"{C_RESET}")
        print(f"  {C_CYAN}[#]{C_RESET} Back to Main Menu Hub")
        print(f"  {C_RED}[*]{C_RESET} Full Exit to Terminal")
        print(f"{C_CYAN}═"*60 + f"{C_RESET}")

        choice = input(f"{C_GREEN}➤ Select Platform (1-5): {C_RESET}").strip().lower()
        if choice in ['#', 'b', 'back']: break
        elif choice in ['*', 'x', 'exit', 'q']: sys.exit(0)

        platform_map = {'1': 'Facebook', '2': 'Instagram', '3': 'TeraBox', '4': 'Universal', '5': 'YouTube'}
        if choice in platform_map:
            p_name = platform_map[choice]
            clear_screen()
            print(f"{C_YELLOW}[*] Selected Platform: {C_CYAN}{p_name} Pro Downloader{C_RESET}\n")
            url = input(f"{C_GREEN}➤ Paste {p_name} URL ([#] Back / [*] Exit): {C_RESET}").strip()
            if url.lower() in ['#', 'b', 'back']: continue
            elif url.lower() in ['*', 'x', 'exit', 'q']: sys.exit(0)
            elif url:
                out_dir = get_download_dir()
                os.makedirs(out_dir, exist_ok=True)
                run_yt_dlp(url, out_dir)
                input(f"\n{C_GREEN}✅ Download Finished. Press Enter...{C_RESET}")
        else:
            input(f"\n{C_RED}❌ Invalid option! Press Enter...{C_RESET}")

if __name__ == "__main__": main()
