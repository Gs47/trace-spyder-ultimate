import os, sys, subprocess

C_CYAN = "\033[1;36m"
C_GREEN = "\033[1;32m"
C_YELLOW = "\033[1;33m"
C_RED = "\033[1;31m"
C_MAGENTA = "\033[1;35m"
C_WHITE = "\033[1;37m"
C_RESET = "\033[0m"

BANNER = f"""{C_CYAN}┌──────────────────────────────────────────────┐
{C_WHITE}   ████████╗██████╗  █████╗  ██████╗███████╗
   ╚══██╔══╝██╔══██╗██╔══██╗██╔════╝██╔════╝
      ██║   ██████╔╝███████║██║     █████╗  
      ██║   ██╔══██╗██╔══██║██║     ██╔══╝  
      ██║   ██║  ██║██║  ██║╚██████╗███████╗
      ╚═╝   ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚══════╝

   ███████╗██████╗ ██╗   ██╗██████╗ ███████╗
   ██╔════╝██╔══██╗╚██╗ ██╔╝██╔══██╗██╔════╝
   ███████╗██████╔╝ ╚████╔╝ ██║  ██║█████╗  
   ╚════██║██╔═══╝   ╚██╔╝  ██║  ██║██╔══╝  
   ███████║██║        ██║   ██████╔╝███████╗
   ╚══════╝╚═╝        ╚═╝   ╚═════╝ ╚══════╝
{C_RESET}
          {C_YELLOW}🕷️ {C_CYAN}GOWRISANKAR B{C_YELLOW} 🕷️{C_RESET}
            {C_MAGENTA}⚡ {C_GREEN}TERMINAL HUB{C_MAGENTA} ⚡{C_RESET}
{C_CYAN}└──────────────────────────────────────────────┘{C_RESET}"""

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')
    print(BANNER)
    print(f"{C_MAGENTA} [▸] ACTIVE : {C_GREEN}MAIN DASHBOARD (A-Z){C_RESET}")
    print(f"{C_CYAN}────────────────────────────────────────────────{C_RESET}")

def run_script(script_name):
    path = os.path.expanduser(f"~/{script_name}")
    if os.path.exists(path):
        subprocess.run([sys.executable, path])
    else:
        print(f"\n{C_RED}❌ Not found: {script_name}{C_RESET}")
        input("Press Enter...")

def main_menu():
    while True:
        clear_screen()
        print(f"  {C_YELLOW}─── [ ALL-IN-ONE CORE ENGINES (A-Z) ] ───{C_RESET}")
        print(f"  {C_CYAN}[01]{C_RESET} Archive ZIP Master Engine")
        print(f"  {C_CYAN}[02]{C_RESET} Cyber Encoder & Decoder")
        print(f"  {C_CYAN}[03]{C_RESET} Cyber Port Scanner & Recon")
        print(f"  {C_CYAN}[04]{C_RESET} Device & Battery Diagnostic")
        print(f"  {C_CYAN}[05]{C_RESET} Encrypted Terminal Notes")
        print(f"  {C_CYAN}[06]{C_RESET} File Security Vault (AES-256)")
        print(f"  {C_CYAN}[07]{C_RESET} Hash Generator & Cracker")
        print(f"  {C_CYAN}[08]{C_RESET} Link Expander & Safety Trace")
        print(f"  {C_CYAN}[09]{C_RESET} Live Crypto & Currency Ticker")
        print(f"  {C_CYAN}[10]{C_RESET} Media & Document Converter")
        print(f"  {C_CYAN}[11]{C_RESET} Network Speedtest & IP Info")
        print(f"  {C_CYAN}[12]{C_RESET} Password & Token Generator")
        print(f"  {C_CYAN}[13]{C_RESET} QR Code Engine (View & Save)")
        print(f"  {C_CYAN}[14]{C_RESET} Seeker OSINT Location Explorer")
        print(f"  {C_CYAN}[15]{C_RESET} Spotify Music/Video Puller")
        print(f"  {C_CYAN}[16]{C_RESET} System Auto Repair Diagnostics")
        print(f"  {C_CYAN}[17]{C_RESET} System CPU & RAM Benchmark")
        print(f"  {C_CYAN}[18]{C_RESET} Telegram Cloud Multi-Sync")
        print(f"  {C_CYAN}[19]{C_RESET} Temp Email & Live Inbox Engine")
        print(f"  {C_CYAN}[20]{C_RESET} TeraBox Fast Stream Downloader")
        print(f"  {C_CYAN}[21]{C_RESET} Termux Storage & Cache Purger")
        print(f"  {C_CYAN}[22]{C_RESET} Universal Media Downloader")
        print(f"  {C_CYAN}[23]{C_RESET} Web Headers & Security Recon")
        print(f"{C_CYAN}────────────────────────────────────────────────{C_RESET}")
        print(f"  {C_MAGENTA}⚙️  [24] CONTROL SETTINGS HUB{C_RESET}")
        print(f"  {C_YELLOW}🌟 [25] ABOUT TRACE SPYDER (MANUAL){C_RESET}")
        print(f"{C_CYAN}────────────────────────────────────────────────{C_RESET}")
        print(f"  {C_YELLOW}[00]{C_RESET} Refresh Dashboard   {C_RED}[*]{C_RESET} Exit Terminal")
        print(f"{C_CYAN}════════════════════════════════════════════════{C_RESET}")

        choice = input(f"{C_GREEN}➤ Select Option (1-25): {C_RESET}").strip().lower()
        mapping = {
            '1': 'zip_master.py', '01': 'zip_master.py',
            '2': 'encoder_tool.py', '02': 'encoder_tool.py',
            '3': 'recon_tool.py', '03': 'recon_tool.py',
            '4': 'device_info.py', '04': 'device_info.py',
            '5': 'notes_tool.py', '05': 'notes_tool.py',
            '6': 'file_vault.py', '06': 'file_vault.py',
            '7': 'hash_tool.py', '07': 'hash_tool.py',
            '8': 'link_unshort.py', '08': 'link_unshort.py',
            '9': 'crypto_tool.py', '09': 'crypto_tool.py',
            '10': 'converter.py',
            '11': 'net_tools.py',
            '12': 'pwgen_tool.py',
            '13': 'qr_tool.py',
            '14': 'seeker_hub.py',
            '15': 'spotify_dl.py',
            '16': 'auto_repair.py',
            '17': 'benchmark_tool.py',
            '18': 'tools.py',
            '19': 'temp_mail.py',
            '20': 'terabox_dl.py',
            '21': 'phone_cleaner.py',
            '22': 'media_dl.py',
            '23': 'web_recon.py',
            '24': 'settings.py',
            '25': 'about.py'
        }
        if choice in mapping:
            run_script(mapping[choice])
        elif choice in ['0', '00']:
            continue
        elif choice in ['*', 'x', 'exit', 'q']:
            print(f"\n{C_RED}Exiting Trace Spyder. Goodbye!{C_RESET}\n")
            sys.exit(0)
        else:
            input(f"\n{C_RED}❌ Invalid Choice! Press Enter...{C_RESET}")

if __name__ == "__main__":
    main_menu()
