import os, sys, subprocess

C_CYAN = "\033[1;36m"
C_GREEN = "\033[1;32m"
C_YELLOW = "\033[1;33m"
C_RED = "\033[1;31m"
C_MAGENTA = "\033[1;35m"
C_WHITE = "\033[1;37m"
C_RESET = "\033[0m"

BANNER = f"""{C_CYAN}┌──────────────────────────────────────────────┐
{C_WHITE}   ████████╗██████╗  █████╗  ██████╗███████╗
   ╚══██╔══╝██╔══██╗██╔══██╗██╔════╝██╔════╝
      ██║   ██████╔╝███████║██║     █████╗  
      ██║   ██╔══██╗██╔══██║██║     ██╔══╝  
      ██║   ██║  ██║██║  ██║╚██████╗███████╗
      ╚═╝   ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚══════╝
{C_RESET}
          {C_YELLOW}🕷️ {C_CYAN}GOWRISANKAR B{C_YELLOW} 🕷️{C_RESET}
            {C_MAGENTA}⚡ {C_GREEN}CONTROL & UPDATE HUB{C_MAGENTA} ⚡{C_RESET}
{C_CYAN}└──────────────────────────────────────────────┘{C_RESET}"""

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')
    print(BANNER)
    print(f"{C_MAGENTA} [▸] ACTIVE : {C_GREEN}SYSTEM SETTINGS & MANUAL UPDATER{C_RESET}")
    print(f"{C_CYAN}────────────────────────────────────────────────{C_RESET}")

def update_system():
    clear_screen()
    print(f"{C_YELLOW}[*] Checking for Updates & Upgrading Core Engines...{C_RESET}\n")
    packages = ["yt-dlp", "spotdl", "telethon", "requests", "pillow", "qrcode", "cryptography", "speedtest-cli"]
    
    print(f"[*] Upgrading pip package installer...")
    subprocess.run([sys.executable, "-m", "pip", "install", "--upgrade", "pip"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    
    for pkg in packages:
        print(f"[*] Updating module: {C_WHITE}{pkg}{C_RESET}...")
        subprocess.run([sys.executable, "-m", "pip", "install", "--upgrade", pkg], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        
    print(f"\n{C_GREEN}✅ All Modules, Libraries & Downloaders Updated Successfully!{C_RESET}")
    input(f"\n{C_YELLOW}Press Enter to return...{C_RESET}")

def main():
    while True:
        clear_screen()
        print(f"  {C_CYAN}[1]{C_RESET} Check & Update All Core Engines / Downloaders")
        print(f"  {C_CYAN}[2]{C_RESET} Clear Temporary App Cache & Reset Logins")
        print(f"{C_CYAN}────────────────────────────────────────────────{C_RESET}")
        print(f"  {C_CYAN}[#]{C_RESET} Back to Main Dashboard")
        print(f"  {C_RED}[*]{C_RESET} Full Exit to Terminal")
        print(f"{C_CYAN}════════════════════════════════════════════════{C_RESET}")

        c = input(f"{C_GREEN}➤ Option (1-2): {C_RESET}").strip().lower()
        if c == '1': update_system()
        elif c == '2':
            for f in [".tg_active_session_name.txt", ".temp_active_mail.txt"]:
                p = os.path.expanduser(f"~/{f}")
                if os.path.exists(p): os.remove(p)
            print(f"\n{C_GREEN}✅ System configurations & cache reset!{C_RESET}")
            input("Press Enter...")
        elif c in ['#', 'b', 'back']: break
        elif c in ['*', 'x', 'exit', 'q']: sys.exit(0)

if __name__ == "__main__":
    main()
