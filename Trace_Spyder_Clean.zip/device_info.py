import os, sys, subprocess, shutil

C_CYAN = "\033[1;36m"
C_GREEN = "\033[1;32m"
C_YELLOW = "\033[1;33m"
C_RED = "\033[1;31m"
C_MAGENTA = "\033[1;35m"
C_WHITE = "\033[1;37m"
C_RESET = "\033[0m"

BANNER = """[1;36m┌────────────────────────────────────────────────────────────┐
[1;37m  ████████╗██████╗  █████╗  ██████╗███████╗
  ╚══██╔══╝██╔══██╗██╔══██╗██╔════╝██╔════╝
     ██║   ██████╔╝███████║██║     █████╗  
     ██║   ██╔══██╗██╔══██║██║     ██╔══╝  
     ██║   ██║  ██║██║  ██║╚██████╗███████╗
     ╚═╝   ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚══════╝

  ███████╗██████╗ ██╗   ██╗██████╗ ███████╗██████╗ 
  ██╔════╝██╔══██╗╚██╗ ██╔╝██╔══██╗██╔════╝██╔══██╗
  ███████╗██████╔╝ ╚████╔╝ ██║  ██║█████╗  ██████╔╝
  ╚════██║██╔═══╝   ╚██╔╝  ██║  ██║██╔══╝  ██╔══██╗
  ███████║██║        ██║   ██████╔╝███████╗██║  ██║
  ╚══════╝╚═╝        ╚═╝   ╚═════╝ ╚══════╝╚═╝  ╚═╝
[0m
         [1;33m🕷️  [1;36mG O W R I   S H A N K A R[1;33m  🕷️[0m
           [1;35m⚡ ═ [1;32mT E R M I N A L   H U B[1;35m ═ ⚡[0m
[1;36m└────────────────────────────────────────────────────────────┘[0m"""

def clear_screen():
    os.system('clear')
    print(BANNER)
    print(f"{C_MAGENTA}  [▸] ACTIVE MODULE : {C_GREEN}DEVICE & BATTERY DIAGNOSTICS{C_RESET}")
    print(f"{C_CYAN}─"*60 + f"{C_RESET}")

def get_battery():
    paths = {
        "level": ["/sys/class/power_supply/battery/capacity", "/sys/class/power_supply/bms/capacity"],
        "status": ["/sys/class/power_supply/battery/status", "/sys/class/power_supply/battery/charging_enabled"]
    }
    lvl, st = "N/A", "Discharging / Idle"
    for p in paths["level"]:
        if os.path.exists(p):
            try:
                with open(p, 'r') as f: lvl = f.read().strip() + "%"; break
            except Exception: pass
    for p in paths["status"]:
        if os.path.exists(p):
            try:
                with open(p, 'r') as f: st = f.read().strip(); break
            except Exception: pass
    return lvl, st

def main():
    while True:
        clear_screen()
        try:
            total, used, free = shutil.disk_usage('/sdcard')
            print(f"{C_CYAN}[*]{C_RESET} Internal Storage (/sdcard):")
            print(f"    - Total Capacity : {C_YELLOW}{total / (1024**3):.2f} GB{C_RESET}")
            print(f"    - Used Space     : {C_RED}{used / (1024**3):.2f} GB{C_RESET}")
            print(f"    - Free Available : {C_GREEN}{free / (1024**3):.2f} GB{C_RESET}")
        except Exception as e:
            print(f"[*] Storage Error: {e}")
            
        print(f"{C_CYAN}─"*60 + f"{C_RESET}")
        batt_lvl, batt_st = get_battery()
        print(f"{C_CYAN}[*]{C_RESET} Battery Diagnostics:")
        print(f"    - Current Level  : {C_GREEN}{batt_lvl}{C_RESET}")
        print(f"    - Battery State  : {C_YELLOW}{batt_st}{C_RESET}")
        print(f"{C_CYAN}─"*60 + f"{C_RESET}")
        print(f"{C_CYAN}[*]{C_RESET} Architecture     : {C_WHITE}{os.uname().machine}{C_RESET}")
        print(f"{C_CYAN}═"*60 + f"{C_RESET}")
        print(f"  {C_YELLOW}[0]{C_RESET} Refresh Status")
        print(f"  {C_CYAN}[#]{C_RESET} Back to Main Menu")
        print(f"  {C_RED}[*]{C_RESET} Full Exit to Terminal")
        print(f"{C_CYAN}═"*60 + f"{C_RESET}")
        c = input(f"{C_GREEN}➤ Option: {C_RESET}").strip().lower()
        if c == '0': continue
        elif c in ['#', 'b', 'back']: break
        elif c in ['*', 'x', 'exit', 'q']: os._exit(0)

if __name__ == "__main__": main()
